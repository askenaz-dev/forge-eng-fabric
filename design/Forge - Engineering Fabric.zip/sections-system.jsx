/* sections-system.jsx
   Iconography · Components · Voice · Product · Closing
*/
/* global window, React, ForgeMark, I, WeavePattern */

// ── Iconography ─────────────────────────────────────────────────────────────
function Icons({ t }) {
  const k = t.icons;
  return (
    <section className="chapter alt" id="ch-05" data-screen-label="05 Icons">
      <div className="chapter-num">
        <span>05</span>
        <span className="rule" />
        <span>{k.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{k.title}</h2>
      <p className="chapter-lede">{k.lede}</p>

      <div className="grid-4" style={{ marginTop: 'var(--s-8)' }}>
        {k.grid.map(([key, label, slug]) => {
          const IconCmp = I[key];
          return (
            <div key={key} className="icon-tile">
              {IconCmp && <IconCmp />}
              <div className="nm">{label}<small>I.{slug}</small></div>
              {(key === 'forge' || key === 'spark') && <span className="ember-dot" />}
            </div>
          );
        })}
      </div>

      <div className="two-col" style={{ marginTop: 'var(--s-10)' }}>
        <div>
          <div className="h-eyebrow">Anatomía · Anatomy</div>
          <div className="constr" style={{ marginTop: 'var(--s-3)', minHeight: 240 }}>
            <span className="crosshair">stroke · 1.5px</span>
            <svg width="200" height="200" viewBox="0 0 200 200" fill="none">
              <defs>
                <pattern id="ig" width="14" height="14" patternUnits="userSpaceOnUse">
                  <path d="M0 0 H14 M0 0 V14" stroke="var(--border)" strokeWidth=".5" />
                </pattern>
              </defs>
              <rect width="200" height="200" fill="url(#ig)" />
              <g transform="translate(28,28) scale(6)" stroke="var(--fg)" strokeWidth="1.5" fill="none">
                <path d="M3 12 L21 12 L19 16 H5 Z" />
                <path d="M10 12 V8 H14 V12" />
                <path d="M6 20 H18" />
                <path d="M9 16 V20 M15 16 V20" />
              </g>
              {/* call-outs */}
              <line x1="172" y1="100" x2="200" y2="100" stroke="var(--primary)" strokeWidth="1" />
              <text x="186" y="116" fontFamily="var(--f-mono)" fontSize="9" fill="var(--primary)" textAnchor="middle">24u</text>
              <line x1="100" y1="172" x2="100" y2="200" stroke="var(--primary)" strokeWidth="1" />
            </svg>
          </div>
        </div>
        <div>
          <div className="h-eyebrow">Reglas · Rules</div>
          <ul style={{ listStyle: 'none', padding: 0, margin: 'var(--s-3) 0 0', display: 'flex', flexDirection: 'column', gap: 'var(--s-3)' }}>
            {[
              ['1.5px', 'Trazo único. Sin variación entre líneas exteriores e interiores.'],
              ['24u', 'Grid base. Todo el dibujo cabe en la caja, nunca toca los bordes.'],
              ['square', 'Cap y join cuadrados — la herrería no redondea.'],
              ['ember', 'Punto brasa opcional para indicar estado activo (1.2u Ø).'],
              ['mono', 'Un icono, un sustantivo. Sin escenas, sin combinaciones.'],
            ].map(([k1, v]) => (
              <li key={k1} style={{ display: 'grid', gridTemplateColumns: '70px 1fr', gap: 12, alignItems: 'baseline', borderTop: '1px solid var(--border)', paddingTop: 'var(--s-3)' }}>
                <span className="mono" style={{ fontSize: 11, letterSpacing: '.08em', color: 'var(--primary)', textTransform: 'uppercase' }}>{k1}</span>
                <span style={{ color: 'var(--fg-2)', fontSize: 14 }}>{v}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

// ── Components ─────────────────────────────────────────────────────────────
function Components({ t, cli }) {
  const k = t.components;
  const spacing = [
    ['1u',  4],
    ['2u',  8],
    ['3u',  12],
    ['4u',  16],
    ['6u',  24],
    ['8u',  32],
    ['12u', 48],
    ['16u', 64],
  ];

  return (
    <section className="chapter" id="ch-06" data-screen-label="06 Components">
      <div className="chapter-num">
        <span>06</span>
        <span className="rule" />
        <span>{k.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{k.title}</h2>
      <p className="chapter-lede">{k.lede}</p>

      <div className="two-col" style={{ marginTop: 'var(--s-8)' }}>
        <div>
          <div className="h-eyebrow">{k.buttons}</div>
          <div className="surface" style={{ marginTop: 'var(--s-3)', display: 'flex', flexWrap: 'wrap', gap: 'var(--s-3)' }}>
            <button className="btn btn--primary">
              <I.bolt width="14" height="14" />
              Forjar el store
            </button>
            <button className="btn btn--secondary">Ver el modelo</button>
            <button className="btn btn--ghost">Cancelar</button>
            <button className="btn btn--primary btn--mono">$ forge up</button>
            <button className="btn btn--secondary btn--mono">v1.0.0</button>
          </div>
        </div>
        <div>
          <div className="h-eyebrow">{k.badges}</div>
          <div className="surface" style={{ marginTop: 'var(--s-3)', display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
            <span className="badge badge--ok"><span className="dot" /> healthy</span>
            <span className="badge badge--warn"><span className="dot" /> degraded</span>
            <span className="badge badge--err"><span className="dot" /> down</span>
            <span className="badge badge--ember"><span className="dot" /> bootstrap</span>
            <span className="badge">idle</span>
            <span className="badge">v1.0.0</span>
            <span className="badge">main · 8a31f</span>
          </div>
        </div>
      </div>

      <div className="two-col" style={{ marginTop: 'var(--s-8)' }}>
        <div>
          <div className="h-eyebrow">{k.cards}</div>
          <div className="surface" style={{ marginTop: 'var(--s-3)', display: 'flex', flexDirection: 'column', gap: 'var(--s-3)' }}>
            {[
              ['fga-authz', 'Autorización · OpenFGA', 'ok'],
              ['api-gateway', 'Ingress · Edge', 'ok'],
              ['compose-orchestrator', 'Orquestación · Compose', 'ok'],
            ].map(([name, sub, st]) => (
              <div key={name} style={{ display: 'grid', gridTemplateColumns: '32px 1fr auto', gap: 12, alignItems: 'center', padding: '12px 14px', background: 'var(--bg-elev)', border: '1px solid var(--border)', borderRadius: 8 }}>
                <span className="pulse" style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--thread)' }} />
                <div>
                  <div style={{ fontFamily: 'var(--f-sans)', fontWeight: 500, fontSize: 14 }}>{name}</div>
                  <div className="mono" style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.04em' }}>{sub}</div>
                </div>
                <span className="badge badge--ok"><span className="dot" /> {st}</span>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div className="h-eyebrow">{k.code}</div>
          <div className="code" style={{ marginTop: 'var(--s-3)' }}>
            <div className="top"><span>fga.model.json</span><span>declarative · authz</span></div>
            <div>{'{'}</div>
            <div>  <span className="c-key">"schema_version"</span>: <span className="c-str">"1.1"</span>,</div>
            <div>  <span className="c-key">"type_definitions"</span>: [</div>
            <div>    {'{'} <span className="c-key">"type"</span>: <span className="c-str">"service"</span>,</div>
            <div>      <span className="c-key">"relations"</span>: {'{'}</div>
            <div>        <span className="c-key">"owner"</span>: {'{ '}<span className="c-key">"this"</span>: {'{} }'},</div>
            <div>        <span className="c-key">"operator"</span>: {'{ '}<span className="c-key">"this"</span>: {'{} }'}</div>
            <div>      {'}'} {'}'}</div>
            <div>  ]</div>
            <div>{'}'}</div>
          </div>

          {cli && (
            <div className="terminal" style={{ marginTop: 'var(--s-3)' }}>
              <div className="body" style={{ padding: '14px 18px' }}>
                <div><span className="prompt">$</span> forge bootstrap <span className="dim">--store=acme</span></div>
                <div className="ok">✓ store created · id=01HXY... · 412ms</div>
                <div className="ok">✓ model authored · v=2026.05.10</div>
                <div className="dim"># env vars exported to compose</div>
                <div><span className="prompt">$</span> <span className="cursor" /></div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div style={{ marginTop: 'var(--s-10)' }}>
        <div className="h-eyebrow">{k.spacing}</div>
        <div className="surface" style={{ marginTop: 'var(--s-3)' }}>
          {spacing.map(([name, px]) => (
            <div key={name} className="spacing-row">
              <span className="nm">{name}</span>
              <span className="bar" style={{ width: px * 6 }} />
              <span className="val">{px}px</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Voice ──────────────────────────────────────────────────────────────────
function Voice({ t }) {
  const k = t.voice;
  return (
    <section className="chapter alt" id="ch-07" data-screen-label="07 Voice">
      <div className="chapter-num">
        <span>07</span>
        <span className="rule" />
        <span>{k.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{k.title}</h2>
      <p className="chapter-lede">{k.lede}</p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--s-4)', marginTop: 'var(--s-8)' }}>
        {k.pairs.map(([yes, no], i) => (
          <div key={i} className="voice-card">
            <div className="do">
              <h4><I.spark width="12" height="12" /> {k.do}</h4>
              <p>{yes}</p>
            </div>
            <div className="dont">
              <h4>✕ {k.dont}</h4>
              <p style={{ color: 'var(--fg-2)' }}>{no}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid-3" style={{ marginTop: 'var(--s-10)' }}>
        {k.principles.map(([title, body], i) => (
          <div key={i} className="surface">
            <div className="mono" style={{ fontSize: 11, letterSpacing: '.12em', color: 'var(--primary)', textTransform: 'uppercase' }}>P.0{i+1}</div>
            <div className="serif" style={{ fontStyle: 'italic', fontSize: 26, lineHeight: 1.15, marginTop: 6, letterSpacing: '-0.01em' }}>{title}</div>
            <p style={{ marginTop: 16, color: 'var(--fg-2)', fontSize: 14, marginBottom: 0 }}>{body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

// ── Product (the brand in use) ─────────────────────────────────────────────
function Product({ t, cli, theme }) {
  const k = t.product;
  return (
    <section className="chapter" id="ch-08" data-screen-label="08 Product">
      <div className="chapter-num">
        <span>08</span>
        <span className="rule" />
        <span>{k.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{k.title}</h2>
      <p className="chapter-lede">{k.lede}</p>

      {/* Landing hero applied */}
      <div style={{ marginTop: 'var(--s-8)' }}>
        <div className="h-eyebrow">{k.landingTitle}</div>
        <div className="app-frame" style={{ marginTop: 'var(--s-3)' }}>
          <div className="app-bar">
            <span className="traffic"><i /><i /><i /></span>
            <span className="app-url">forge.platform / inicio</span>
            <span className="mono" style={{ fontSize: 11, color: 'var(--fg-3)' }}>v1.0</span>
          </div>
          <div style={{ padding: 'var(--s-10) var(--s-8) var(--s-8)', position: 'relative', overflow: 'hidden' }}>
            <WeavePattern id="land-weave" spacing={28} />
            <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 'var(--s-8)', alignItems: 'center' }}>
              <div>
                <span className="badge badge--ember"><span className="dot" /> engineering fabric · v1.0</span>
                <h3 style={{ fontFamily: 'var(--f-display)', fontSize: 'clamp(40px, 5vw, 72px)', lineHeight: .98, letterSpacing: '-0.025em', margin: '14px 0 0', fontWeight: 400 }}>
                  {k.landingHero.split(' ').slice(0, -3).join(' ')}{' '}
                  <em style={{ fontStyle: 'italic', color: 'var(--primary)' }}>{k.landingHero.split(' ').slice(-3).join(' ')}</em>
                </h3>
                <p style={{ marginTop: 18, color: 'var(--fg-2)', fontSize: 16, lineHeight: 1.6, maxWidth: '52ch' }}>{k.landingSub}</p>
                <div style={{ marginTop: 24, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                  <button className="btn btn--primary"><I.bolt width="14" height="14" /> {k.ctaPrimary}</button>
                  <button className="btn btn--secondary">{k.ctaSecondary}</button>
                </div>
                <div style={{ marginTop: 32, display: 'flex', gap: 24, color: 'var(--fg-3)', fontFamily: 'var(--f-mono)', fontSize: 11, letterSpacing: '.1em', textTransform: 'uppercase', flexWrap: 'wrap' }}>
                  <span>· docker compose</span>
                  <span>· openfga</span>
                  <span>· bootstrap as code</span>
                </div>
              </div>

              <LandingDataviz />
            </div>
          </div>

          {/* Metric strip */}
          <div className="metric-grid" style={{ padding: 'var(--s-5)', borderTop: '1px solid var(--border)', background: 'var(--bg-2)', gridTemplateColumns: 'repeat(4, 1fr)' }}>
            {k.metrics.map(([lbl, num, unit], i) => (
              <div key={i} className="metric" style={{ background: 'var(--bg-elev)' }}>
                <div className="lbl">{lbl}</div>
                <div className="num">{num}<small>{unit}</small></div>
                <div className="delta">▲ healthy</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Service console */}
      <div style={{ marginTop: 'var(--s-10)' }}>
        <div className="h-eyebrow">{k.consoleTitle}</div>
        <p className="body-text" style={{ marginTop: 4, marginBottom: 'var(--s-3)' }}>{k.consoleSub}</p>

        {cli ? <CliConsole t={t} /> : <GuiConsole t={t} />}
      </div>

      {/* ReBAC mini */}
      <div className="two-col" style={{ marginTop: 'var(--s-10)' }}>
        <div>
          <div className="h-eyebrow">{k.rebacTitle}</div>
          <p className="body-text" style={{ marginTop: 4 }}>{k.rebacSub}</p>
          <div className="code" style={{ marginTop: 'var(--s-3)' }}>
            <div className="top"><span>relations.fga</span><span>type · service</span></div>
            <div><span className="c-com"># every service can be owned, operated, observed.</span></div>
            <div><span className="c-key">type</span> <span className="c-fn">service</span></div>
            <div>  <span className="c-key">relations</span></div>
            <div>    <span className="c-key">define</span> <span className="c-em">owner</span>: [<span className="c-fn">user</span>, <span className="c-fn">team</span>]</div>
            <div>    <span className="c-key">define</span> <span className="c-em">operator</span>: [<span className="c-fn">user</span>, <span className="c-fn">team</span>] <span className="c-com">or owner</span></div>
            <div>    <span className="c-key">define</span> <span className="c-em">observer</span>: [<span className="c-fn">user</span>, <span className="c-fn">team</span>] <span className="c-com">or operator</span></div>
          </div>
        </div>
        <RebacGraph />
      </div>
    </section>
  );
}

// Dataviz — the loom: hero illustration weaving threads with health dots
function LandingDataviz() {
  const [phase, setPhase] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setPhase(p => (p + 1) % 360), 80);
    return () => clearInterval(id);
  }, []);
  return (
    <div style={{
      position: 'relative',
      background: 'var(--bg-card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--r-3)',
      padding: 'var(--s-5)',
      minHeight: 340,
      overflow: 'hidden',
    }}>
      <div className="mono" style={{ position: 'absolute', top: 14, left: 16, fontSize: 10, letterSpacing: '.14em', textTransform: 'uppercase', color: 'var(--fg-3)' }}>
        live · service mesh
      </div>
      <div className="mono" style={{ position: 'absolute', top: 14, right: 16, fontSize: 10, letterSpacing: '.14em', textTransform: 'uppercase', color: 'var(--thread)' }}>
        ● 23 / 24
      </div>
      <svg viewBox="0 0 400 340" width="100%" height="100%" style={{ marginTop: 20 }}>
        <defs>
          <linearGradient id="thread-grad" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stopColor="var(--primary)" stopOpacity="0" />
            <stop offset="50%" stopColor="var(--primary)" stopOpacity=".7" />
            <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
          </linearGradient>
        </defs>
        {/* warp (vertical) threads */}
        {Array.from({ length: 9 }).map((_, i) => (
          <line key={'w'+i} x1={40 + i * 40} y1="20" x2={40 + i * 40} y2="320"
                stroke="var(--border-strong)" strokeWidth=".75" opacity=".6" />
        ))}
        {/* weft (horizontal) threads */}
        {Array.from({ length: 8 }).map((_, i) => (
          <line key={'h'+i} x1="20" y1={40 + i * 36} x2="380" y2={40 + i * 36}
                stroke="var(--border-strong)" strokeWidth=".75" opacity=".4" />
        ))}
        {/* a thread of fire that animates */}
        <g style={{ transform: `translateX(${(phase % 360) - 60}px)`, transition: 'none' }}>
          <line x1="0" y1="124" x2="120" y2="124" stroke="url(#thread-grad)" strokeWidth="2.5" />
        </g>
        <g style={{ transform: `translateX(${((phase + 180) % 360) - 60}px)` }}>
          <line x1="0" y1="232" x2="120" y2="232" stroke="url(#thread-grad)" strokeWidth="2.5" />
        </g>
        {/* nodes (services) */}
        {[
          [80, 84, 'ok'],
          [160, 124, 'ok'],
          [240, 84, 'ok'],
          [320, 160, 'warn'],
          [120, 196, 'ok'],
          [200, 232, 'ok'],
          [280, 268, 'ok'],
          [80, 268, 'err'],
          [344, 232, 'ok'],
        ].map(([x, y, st], i) => {
          const color = st === 'ok' ? 'var(--thread)' : st === 'warn' ? 'var(--spark)' : 'var(--rust)';
          return (
            <g key={i}>
              <circle cx={x} cy={y} r="9" fill="var(--bg-elev)" stroke={color} strokeWidth="1.5" />
              <circle cx={x} cy={y} r="3" fill={color}>
                {st === 'ok' && (
                  <animate attributeName="opacity" values="1;.4;1" dur={`${1.4 + i * 0.1}s`} repeatCount="indefinite" />
                )}
              </circle>
            </g>
          );
        })}
        {/* Forge mark in center */}
        <g transform="translate(170 130) scale(2)">
          <rect width="32" height="32" fill="var(--bg-card)" rx="3" />
          <path d="M6 4 H24 L26 6 V10 H22 V8 H10 V14 H20 V18 H10 V28 H6 Z" fill="var(--fg)" />
          <circle cx="25" cy="25" r="2.4" fill="var(--primary)" />
        </g>
      </svg>
    </div>
  );
}

function GuiConsole({ t }) {
  return (
    <div className="app-frame">
      <div className="app-bar">
        <span className="traffic"><i /><i /><i /></span>
        <span className="app-url">forge.platform / services</span>
        <span className="mono" style={{ fontSize: 11, color: 'var(--fg-3)' }}>compose · profile=engineering</span>
      </div>
      <div className="body">
        <aside className="side">
          <div className="sec">Plataforma</div>
          <a className="active"><I.service /> Servicios</a>
          <a><I.graph /> Modelo ReBAC</a>
          <a><I.book /> Bootstrap</a>
          <a><I.cog /> Entornos</a>
          <div className="sec">Datos</div>
          <a><I.doc /> Logs</a>
          <a><I.console /> Consola</a>
          <div className="sec">Equipo</div>
          <a><I.seal /> Políticas</a>
        </aside>
        <main className="main">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 16 }}>
            <div>
              <h4 className="serif" style={{ margin: 0, fontSize: 28, fontWeight: 400, letterSpacing: '-0.015em' }}>
                Servicios <em style={{ color: 'var(--primary)' }}>en vivo</em>
              </h4>
              <p className="mono" style={{ margin: '4px 0 0', fontSize: 11, letterSpacing: '.1em', textTransform: 'uppercase', color: 'var(--fg-3)' }}>
                compose · profile=engineering · refresh 2s
              </p>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn--secondary btn--mono">refresh</button>
              <button className="btn btn--primary"><I.bolt width="14" height="14" /> deploy</button>
            </div>
          </div>

          <div className="surface" style={{ padding: 0 }}>
            {t.product.services.map(([name, kind, st, err, lat]) => (
              <div key={name} className="svc-row">
                <span className={`pulse ${st === 'ok' ? '' : st}`} />
                <span className="svc-name">{name}<small>{kind}</small></span>
                <span style={{ color: 'var(--fg-3)' }}>{err}</span>
                <span style={{ color: 'var(--fg-3)' }}>{lat}</span>
                <span className={`bars ${st === 'ok' ? 'tone-ok' : st === 'warn' ? 'tone-warn' : ''}`}>
                  {Array.from({ length: 9 }).map((_, i) => <i key={i} style={{ height: `${30 + Math.sin(i + name.length) * 35 + 35}%` }} />)}
                </span>
                <span className={`badge ${st === 'ok' ? 'badge--ok' : st === 'warn' ? 'badge--warn' : st === 'err' ? 'badge--err' : ''}`}>
                  <span className="dot" /> {st === 'idle' ? 'idle' : st === 'ok' ? 'healthy' : st === 'warn' ? 'degraded' : 'down'}
                </span>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}

function CliConsole({ t }) {
  return (
    <div className="terminal">
      <div className="tbar">
        <span className="traffic" style={{ display:'inline-flex', gap:6 }}>
          <i style={{display:'inline-block',width:10,height:10,borderRadius:'50%',background:'#3A332C'}}/>
          <i style={{display:'inline-block',width:10,height:10,borderRadius:'50%',background:'#3A332C'}}/>
          <i style={{display:'inline-block',width:10,height:10,borderRadius:'50%',background:'#3A332C'}}/>
        </span>
        <span className="tab" style={{ marginLeft: 10 }}>forge · ps</span>
        <span style={{ marginLeft: 'auto' }}>profile=engineering · ⓘ live</span>
      </div>
      <div className="body">
        <div><span className="prompt">$</span> forge ps --watch</div>
        <div className="dim">NAME                       KIND            STATUS    ERR%    P95</div>
        {t.product.services.map(([name, kind, st, err, lat]) => {
          const tone = st === 'ok' ? 'ok' : st === 'warn' ? 'warn' : st === 'err' ? 'err' : 'dim';
          const dot = st === 'ok' ? '●' : st === 'warn' ? '◆' : st === 'err' ? '✕' : '○';
          const word = st === 'ok' ? 'healthy ' : st === 'warn' ? 'degraded' : st === 'err' ? 'down    ' : 'idle    ';
          return (
            <div key={name}>
              <span className={tone}>{dot} </span>
              <span>{name.padEnd(27)}</span>
              <span className="dim">{kind.padEnd(16)}</span>
              <span className={tone}>{word}</span>
              <span className="dim">  {err.padStart(5)}  {lat.padStart(5)}</span>
            </div>
          );
        })}
        <div className="dim" style={{ marginTop: 6 }}># press q to exit, r to refresh now</div>
        <div><span className="prompt">$</span> <span className="cursor" /></div>
      </div>
    </div>
  );
}

function RebacGraph() {
  return (
    <div className="graph">
      <span className="mono" style={{ position: 'absolute', top: 14, left: 16, fontSize: 10, letterSpacing: '.14em', textTransform: 'uppercase', color: 'var(--fg-3)' }}>
        rebac · live · check(diana, observer, billing-svc)
      </span>
      <span className="mono" style={{ position: 'absolute', top: 14, right: 16, fontSize: 10, letterSpacing: '.14em', textTransform: 'uppercase', color: 'var(--thread)' }}>
        ✓ allow · 3ms
      </span>
      <svg viewBox="0 0 500 320" width="100%" height="auto" style={{ marginTop: 32 }}>
        <defs>
          <marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0 0 L10 5 L0 10 Z" fill="var(--border-strong)" />
          </marker>
        </defs>
        {/* edges */}
        <path d="M120 80 C200 80 220 160 250 160" fill="none" stroke="var(--border-strong)" strokeWidth="1" markerEnd="url(#arr)" />
        <path d="M120 160 L250 160" fill="none" stroke="var(--primary)" strokeWidth="1.5" markerEnd="url(#arr)" strokeDasharray="3 3">
          <animate attributeName="stroke-dashoffset" values="0;-6" dur="0.6s" repeatCount="indefinite" />
        </path>
        <path d="M120 240 C200 240 220 160 250 160" fill="none" stroke="var(--border-strong)" strokeWidth="1" markerEnd="url(#arr)" />
        <path d="M320 160 C360 100 400 90 430 110" fill="none" stroke="var(--thread)" strokeWidth="1.5" markerEnd="url(#arr)" />
        <path d="M320 160 C360 160 400 160 430 160" fill="none" stroke="var(--thread)" strokeWidth="1.5" markerEnd="url(#arr)" />
        <path d="M320 160 C360 220 400 230 430 210" fill="none" stroke="var(--thread)" strokeWidth="1.5" markerEnd="url(#arr)" />

        {/* nodes */}
        {/* users */}
        {[['Diana', 80, 'user'], ['Marco', 80, 'user', 160], ['Ana', 80, 'user', 240]].map(([nm, x, kind, y], i) => {
          const yy = [80, 160, 240][i];
          return (
            <g key={nm} transform={`translate(60 ${yy})`}>
              <rect x="-60" y="-18" width="120" height="36" rx="18" fill="var(--bg-elev)" stroke="var(--border-strong)" />
              <circle cx="-40" cy="0" r="6" fill="var(--copper)" />
              <text x="-26" y="4" fontFamily="var(--f-mono)" fontSize="11" fill="var(--fg)">{nm}</text>
            </g>
          );
        })}
        {/* team */}
        <g transform="translate(285 160)">
          <rect x="-50" y="-22" width="100" height="44" rx="6" fill="var(--bg-elev)" stroke="var(--steel)" strokeWidth="1.5" />
          <text x="0" y="-2" fontFamily="var(--f-mono)" fontSize="10" textAnchor="middle" fill="var(--fg-3)">team</text>
          <text x="0" y="14" fontFamily="var(--f-sans)" fontSize="12.5" fontWeight="500" textAnchor="middle" fill="var(--fg)">platform</text>
        </g>
        {/* services */}
        {[['api', 110], ['billing-svc', 160, true], ['fga-authz', 210]].map(([nm, yy, hl]) => (
          <g key={nm} transform={`translate(465 ${yy})`}>
            <rect x="-60" y="-16" width="120" height="32" rx="4"
                  fill={hl ? 'color-mix(in oklch, var(--primary), transparent 88%)' : 'var(--bg-elev)'}
                  stroke={hl ? 'var(--primary)' : 'var(--border-strong)'} strokeWidth={hl ? 1.5 : 1} />
            <text x="0" y="-1" fontFamily="var(--f-mono)" fontSize="9" textAnchor="middle" fill="var(--fg-3)">service</text>
            <text x="0" y="11" fontFamily="var(--f-mono)" fontSize="11" textAnchor="middle" fill={hl ? 'var(--primary)' : 'var(--fg)'}>{nm}</text>
          </g>
        ))}
        {/* edge labels */}
        <text x="190" y="156" fontFamily="var(--f-mono)" fontSize="10" fill="var(--primary)">member</text>
        <text x="375" y="155" fontFamily="var(--f-mono)" fontSize="10" fill="var(--thread)">operator</text>
      </svg>
    </div>
  );
}

// ── Closing / Colophon ─────────────────────────────────────────────────────
function Closing({ t }) {
  return (
    <section className="colophon" id="ch-end" data-screen-label="09 Colophon">
      <h2>{t.closing.title}<em>{t.closing.titleEm}</em>{t.closing.titleAfter}</h2>
      <div className="grid">
        {t.closing.cols.map(([h, body], i) => (
          <div key={i}>
            <h5>{h}</h5>
            <p>{body}</p>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 'var(--s-8)', display: 'flex', justifyContent: 'space-between', gap: 16, alignItems: 'center', borderTop: '1px solid #2A2521', paddingTop: 24, color: '#7F7669', flexWrap: 'wrap' }}>
        <span className="logo" style={{ color: 'var(--paper)' }}>
          <ForgeMark size={24} />
          <span className="word">forge</span>
        </span>
        <span>— fin del cuaderno · end of notebook —</span>
        <span>↦ {t.cover.version}</span>
      </div>
    </section>
  );
}

Object.assign(window, { Icons, Components, Voice, Product, Closing });
