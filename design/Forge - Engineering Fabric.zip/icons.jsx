/* icons.jsx — Forge custom icon set
   1.5px stroke, square caps, optional ember accent.
   All icons use currentColor for the stroke; the ember dot is var(--primary). */
/* global window */

const ForgeMark = ({ size = 28, ember = true }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
    {/* Geometric F built from grid. Top bar has a notched right edge (anvil horn). */}
    <path d="M6 4 H24 L26 6 V10 H22 V8 H10 V14 H20 V18 H10 V28 H6 Z"
          fill="currentColor" />
    {ember && <circle cx="25" cy="25" r="2.4" fill="var(--primary)" />}
  </svg>
);

const I = {
  forge: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"
         strokeLinecap="square" strokeLinejoin="miter" {...p}>
      {/* anvil silhouette */}
      <path d="M3 12 L21 12 L19 16 H5 Z" />
      <path d="M10 12 V8 H14 V12" />
      <path d="M6 20 H18" />
      <path d="M9 16 V20 M15 16 V20" />
    </svg>
  ),
  weave: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
      {/* warp + weft */}
      <path d="M4 7 H20 M4 12 H20 M4 17 H20" />
      <path d="M7 4 V20 M12 4 V20 M17 4 V20" />
      <circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none" />
    </svg>
  ),
  anvil: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
      <path d="M3 9 H17 L21 12 H17 L17 14 H5 L3 12 Z" />
      <path d="M7 14 V19 H15 V14" />
      <path d="M5 21 H17" />
    </svg>
  ),
  spark: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
      <path d="M12 3 L13.6 9.4 L20 11 L13.6 12.6 L12 19 L10.4 12.6 L4 11 L10.4 9.4 Z" />
    </svg>
  ),
  plan: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
      <rect x="3.5" y="4.5" width="17" height="15" />
      <path d="M3.5 9 H20.5 M8 4.5 V19.5 M14 9 V19.5" />
    </svg>
  ),
  link: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
      <circle cx="7" cy="12" r="3" />
      <circle cx="17" cy="12" r="3" />
      <path d="M10 12 H14" />
    </svg>
  ),
  seal: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
      <path d="M12 3 L20 7 V13 C20 17 16 20 12 21 C8 20 4 17 4 13 V7 Z" />
      <path d="M9 12 L11 14 L15 10" />
    </svg>
  ),
  scope: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
      <circle cx="11" cy="11" r="6" />
      <path d="M15 15 L20 20" />
      <path d="M8 11 H14 M11 8 V14" />
    </svg>
  ),

  // chrome / nav icons
  service:  (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><rect x="3.5" y="5.5" width="17" height="4"/><rect x="3.5" y="14.5" width="17" height="4"/><circle cx="7" cy="7.5" r=".6" fill="currentColor"/><circle cx="7" cy="16.5" r=".6" fill="currentColor"/></svg>,
  console:  (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><rect x="3.5" y="4.5" width="17" height="15"/><path d="M7 10 L10 12 L7 14 M12 14 H16"/></svg>,
  graph:    (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M8 6 H16 M7.2 7.6 L11 16.5 M16.8 7.6 L13 16.5"/></svg>,
  bolt:     (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><path d="M13 3 L5 13 H11 L10 21 L19 10 H13 Z"/></svg>,
  cog:      (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><circle cx="12" cy="12" r="3"/><path d="M12 3 V6 M12 18 V21 M3 12 H6 M18 12 H21 M5.6 5.6 L7.7 7.7 M16.3 16.3 L18.4 18.4 M5.6 18.4 L7.7 16.3 M16.3 7.7 L18.4 5.6"/></svg>,
  book:     (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><path d="M4 4 H11 C12 4 12 5 12 6 V20 C12 19 12 18 11 18 H4 Z"/><path d="M20 4 H13 C12 4 12 5 12 6 V20 C12 19 12 18 13 18 H20 Z"/></svg>,
  doc:      (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><path d="M6 3 H15 L19 7 V21 H6 Z"/><path d="M14 3 V8 H19 M9 13 H16 M9 16 H14"/></svg>,
};

// Weave pattern: tileable lattice for backgrounds
const WeavePattern = ({ id = "weave", color = "currentColor", spacing = 20 }) => (
  <svg className="weave-bg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice"
       width="100%" height="100%" aria-hidden="true">
    <defs>
      <pattern id={id} width={spacing / 2} height={spacing / 2} patternUnits="userSpaceOnUse">
        <path d={`M 0 ${spacing/4} H ${spacing/2} M ${spacing/4} 0 V ${spacing/2}`}
              stroke={color} strokeWidth=".25" fill="none" opacity=".5" />
        <circle cx={spacing/4} cy={spacing/4} r=".5" fill={color} opacity=".4" />
      </pattern>
    </defs>
    <rect width="100" height="100" fill={`url(#${id})`} />
  </svg>
);

Object.assign(window, { ForgeMark, I, WeavePattern });
