/* i18n.jsx — Forge brand notebook copy, ES/EN */
/* global window */

const I18N = {
  es: {
    // chrome
    nav: {
      foundations: "Fundamentos",
      identity: "Identidad",
      type: "Tipografía",
      color: "Color",
      icons: "Iconos",
      components: "Componentes",
      voice: "Voz",
      product: "Producto",
    },

    cover: {
      eyebrow: "Brand Notebook",
      version: "v1.0 · Mayo 2026",
      project: "Forge · Engineering Fabric",
      origin: "Bogotá / Internal",
      classification: "Internal — All Squads",
      title1: "Forge",
      title2: "Engineering",
      title3: "Fabric",
      tagline: "El telar donde cada equipo del SDLC teje su parte del sistema.",
      foot1: "Sistema visual & verbal",
      foot2: "Hecho para herramientas",
      foot3: "Notebook ↦ 01",
    },

    toc: {
      eyebrow: "Índice",
      title: "El cuaderno",
      lede: "Un manual vivo. Léelo de principio a fin para entender el carácter, o salta directo al capítulo que necesites mientras diseñas.",
      items: [
        ["01", "Manifiesto", "Por qué tejemos"],
        ["02", "Identidad", "Marca y construcción"],
        ["03", "Color", "Brasa, papel y tinta"],
        ["04", "Tipografía", "Editorial + máquina"],
        ["05", "Iconografía", "Símbolos del SDLC"],
        ["06", "Componentes", "Piezas que se forjan"],
        ["07", "Voz", "Cómo hablamos"],
        ["08", "Producto", "La marca en uso"],
      ],
    },

    manifesto: {
      eyebrow: "Cap. 01 — Manifiesto",
      title: "El telar",
      lede: "Forge no es una herramienta más. Es la trama común sobre la que toda la organización entreteje su trabajo de software.",
      quote: [
        "Una plataforma no es un producto: es un ",
        "telar",
        ". Cada PR, cada modelo de permisos, cada contenedor que arranca son hilos. Forge no tensiona los hilos: forja el bastidor."
      ],
      body: [
        "Diseñamos Forge para que la fricción entre roles — producto, ingeniería, seguridad, SRE, datos — se reemplace por una superficie común. Lo crudo se vuelve estructura.",
        "Cuando un servicio se enciende, no es magia: es un bootstrap deliberado. Los modelos de autorización son declarativos, las relaciones explícitas, los entornos reproducibles. La plataforma se documenta a sí misma.",
        "La marca debe sentir lo mismo: precisa como un plano, cálida como un taller, viva como un grafo en producción.",
      ],
      pillars: [
        ["Forja", "Material en bruto que toma forma deliberada."],
        ["Tejido", "Hilos que sostienen al colectivo."],
        ["Plano", "Toda decisión es medible y declarativa."],
      ],
    },

    identity: {
      eyebrow: "Cap. 02 — Identidad",
      title: "Marca",
      lede: "El logotipo es un símbolo de precisión más una brasa. La precisión sostiene el sistema; la brasa recuerda que aún se trabaja en caliente.",
      construction: "El ancho de la barra equivale a 2 unidades del grid. La brasa se ubica a una unidad del extremo inferior derecho. No alterar las proporciones.",
      clear: "Espacio libre: una unidad-X completa alrededor del símbolo. Nunca menos.",
      lockups: "Lock-ups",
      misuseTitle: "Mal uso",
      misuse: [
        "No estirar ni distorsionar",
        "No reemplazar la brasa por otro color",
        "No usar sobre fondos de bajo contraste",
        "No rotar el símbolo",
      ],
    },

    color: {
      eyebrow: "Cap. 03 — Color",
      title: "Paleta",
      lede: "Una brasa que guía la atención, un papel cálido como base, una tinta seria para todo lo crítico. Los acentos vienen del taller.",
      primary: "Primarios",
      neutrals: "Neutros",
      semantic: "Semánticos",
      semanticDesc: "Reservados para estado. Nunca decorativos.",
      semanticItems: [
        ["thread",  "Verdigris",  "Éxito · servicio sano · permiso concedido"],
        ["spark",   "Chispa",     "Aviso · pendiente · degradado"],
        ["rust",    "Óxido",      "Error · denegado · caído"],
        ["steel",   "Acero",      "Informativo · neutro técnico"],
        ["copper",  "Cobre",      "Decorativo · destaque editorial"],
      ],
      scale: "Escala de la brasa",
    },

    type: {
      eyebrow: "Cap. 04 — Tipografía",
      title: "Voces",
      lede: "Tres familias. Una para titulares editoriales, otra para el cuerpo del producto, otra para el código y las marcas técnicas.",
      display: "Display — Instrument Serif",
      displayUse: "Titulares editoriales, citas, dataviz hero. Sólo en regular e italic.",
      sans: "UI — Geist",
      sansUse: "Interfaz, cuerpo, microcopy. Pesos 400-600.",
      mono: "Mono — JetBrains Mono",
      monoUse: "Código, marcas técnicas, etiquetas de UI, números tabulares.",
      sample: "El telar que sostiene a tu equipo.",
      sampleAlt: "$ forge bootstrap --store=acme --model=./fga.json",
    },

    icons: {
      eyebrow: "Cap. 05 — Iconografía",
      title: "Símbolos",
      lede: "Un icono = un sustantivo del SDLC. Trazo de 1.5px, esquinas vivas, brasa opcional para el estado activo.",
      grid: [
        ["forge", "Servicio", "service"],
        ["weave", "Tejido", "fabric"],
        ["anvil", "Pipeline", "build"],
        ["spark", "Despliegue", "deploy"],
        ["plan",  "Modelo",  "model"],
        ["link",  "Relación", "rel"],
        ["seal",  "Política", "policy"],
        ["scope", "Permiso",  "permit"],
      ],
    },

    components: {
      eyebrow: "Cap. 06 — Componentes",
      title: "Piezas",
      lede: "Las piezas se forjan en el taller; los productos las ensamblan.",
      buttons: "Botones",
      badges: "Etiquetas de estado",
      cards: "Tarjetas y superficies",
      code: "Código y consolas",
      spacing: "Espaciado · escala 4u",
    },

    voice: {
      eyebrow: "Cap. 07 — Voz",
      title: "Tono",
      lede: "Hablamos como un ingeniero senior que también escribe bien. Precisos, directos, con una pizca de oficio.",
      do: "Lo decimos así",
      dont: "Así no",
      pairs: [
        ["Aprovisiona el store en 12 segundos.", "Revolucionamos la autorización con magia AI."],
        ["Los modelos son JSON. Los versionas como código.", "Plataforma sinérgica de próxima generación."],
        ["Si un servicio cae, otro toma el martillo.", "Resiliencia disruptiva 360°."],
      ],
      principles: [
        ["Específico, no genérico", "“Bootstrap del store” es mejor que “configuración inicial”."],
        ["Verbos de oficio", "Forjar, tejer, templar, sellar. Nunca “orquestamos sinergias”."],
        ["Bilingüe", "Español como lengua principal del equipo, inglés para los términos del oficio."],
      ],
    },

    product: {
      eyebrow: "Cap. 08 — Producto",
      title: "En uso",
      lede: "La marca aplicada: la landing, la consola de servicios viva, y un vistazo al modelo ReBAC.",
      landingTitle: "Landing",
      landingHero: "Una sola plataforma. Cada rol del SDLC encuentra su hilo.",
      landingSub: "Forge orquesta servicios con Docker Compose y aprovisiona stores y modelos de OpenFGA antes del primer deploy. El resto del equipo hereda permisos, variables y health checks ya tejidos.",
      ctaPrimary: "Iniciar el telar",
      ctaSecondary: "Ver la arquitectura",
      consoleTitle: "Consola de servicios",
      consoleSub: "Vista en vivo del compose. Health checks tejidos al modelo de permisos.",
      rebacTitle: "Modelo de relaciones",
      rebacSub: "ReBAC declarativo, versionado como código. El grafo es el contrato.",
      metrics: [
        ["Servicios sanos", "23", "/24"],
        ["Latencia p95", "84", "ms"],
        ["Permisos verificados", "1.2", "M/día"],
        ["Bootstraps hoy", "47", ""],
      ],
      services: [
        ["api-gateway",      "Ingress",      "ok",   "0.4%", "12ms"],
        ["fga-authz",        "Autorización", "ok",   "0.1%", "3ms"],
        ["forge-bootstrap",  "Bootstrap",    "idle", "—",    "—"],
        ["compose-orchestrator", "Orquestación", "ok", "0.0%", "8ms"],
        ["postgres-fga",     "Datos",        "ok",   "0.2%", "1ms"],
        ["billing-svc",      "Producto",     "warn", "1.8%", "204ms"],
        ["telemetry-fluent", "Observabilidad", "ok", "0.0%", "—"],
        ["cron-archiver",    "Datos · batch", "err", "—",   "—"],
      ],
    },

    closing: {
      title: "Mantén el ",
      titleEm: "fuego",
      titleAfter: " encendido.",
      cols: [
        ["Curaduría", "Plataforma · Brand Squad · 2025-2026"],
        ["Tipografía", "Instrument Serif · Geist · JetBrains Mono — Open Font License"],
        ["Contacto", "brand@forge.platform"],
        ["Versión", "v1.0 · 2026-05"],
      ],
    },

    tweaks: {
      title: "Tweaks",
      theme: "Tema",
      themeOpts: ["Claro", "Oscuro"],
      density: "Densidad",
      densityOpts: ["Compacta", "Cómoda", "Amplia"],
      mode: "Modo",
      modeOpts: ["GUI", "CLI"],
      lang: "Idioma",
      langOpts: ["ES", "EN"],
      accent: "Acento",
    },
  },

  en: {
    nav: {
      foundations: "Foundations",
      identity: "Identity",
      type: "Type",
      color: "Color",
      icons: "Icons",
      components: "Components",
      voice: "Voice",
      product: "Product",
    },

    cover: {
      eyebrow: "Brand Notebook",
      version: "v1.0 · May 2026",
      project: "Forge · Engineering Fabric",
      origin: "Bogotá / Internal",
      classification: "Internal — All Squads",
      title1: "Forge",
      title2: "Engineering",
      title3: "Fabric",
      tagline: "The loom where every role in the SDLC weaves its part of the system.",
      foot1: "Visual & verbal system",
      foot2: "Built for builders",
      foot3: "Notebook ↦ 01",
    },

    toc: {
      eyebrow: "Contents",
      title: "The notebook",
      lede: "A living manual. Read it cover-to-cover to get the character, or jump straight to the chapter you need while you design.",
      items: [
        ["01", "Manifesto", "Why we weave"],
        ["02", "Identity", "Mark and construction"],
        ["03", "Color", "Ember, paper, ink"],
        ["04", "Type", "Editorial + machine"],
        ["05", "Iconography", "SDLC glyphs"],
        ["06", "Components", "Forged parts"],
        ["07", "Voice", "How we talk"],
        ["08", "Product", "The brand in use"],
      ],
    },

    manifesto: {
      eyebrow: "Ch. 01 — Manifesto",
      title: "The loom",
      lede: "Forge isn't another tool. It's the common warp on which every team weaves its software work.",
      quote: [
        "A platform isn't a product: it's a ",
        "loom",
        ". Every PR, every permission model, every container that boots is a thread. Forge doesn't pull the threads — it forges the frame."
      ],
      body: [
        "We design Forge so the friction between roles — product, engineering, security, SRE, data — gets replaced by a shared surface. Raw turns to structure.",
        "When a service boots, it isn't magic: it's a deliberate bootstrap. Authorization models are declarative, relations explicit, environments reproducible. The platform documents itself.",
        "The brand should feel the same: precise as a blueprint, warm as a workshop, alive as a production graph.",
      ],
      pillars: [
        ["Forge", "Raw material taking deliberate shape."],
        ["Fabric", "Threads that hold the collective."],
        ["Blueprint", "Every decision is measurable and declarative."],
      ],
    },

    identity: {
      eyebrow: "Ch. 02 — Identity",
      title: "Mark",
      lede: "The logotype is a precision symbol plus an ember. Precision holds the system; the ember reminds you it's still hot.",
      construction: "Bar width equals 2 grid units. The ember sits one unit from the bottom-right edge. Never alter proportions.",
      clear: "Clear space: one full x-unit around the mark. Never less.",
      lockups: "Lock-ups",
      misuseTitle: "Misuse",
      misuse: [
        "Don't stretch or distort",
        "Don't recolor the ember",
        "Don't use on low-contrast backgrounds",
        "Don't rotate the mark",
      ],
    },

    color: {
      eyebrow: "Ch. 03 — Color",
      title: "Palette",
      lede: "An ember that guides attention, warm paper as ground, a serious ink for anything critical. Accents come from the workshop.",
      primary: "Primaries",
      neutrals: "Neutrals",
      semantic: "Semantic",
      semanticDesc: "Reserved for state. Never decorative.",
      semanticItems: [
        ["thread",  "Verdigris",  "Success · service healthy · permission granted"],
        ["spark",   "Spark",      "Warning · pending · degraded"],
        ["rust",    "Rust",       "Error · denied · down"],
        ["steel",   "Steel",      "Informational · neutral technical"],
        ["copper",  "Copper",     "Decorative · editorial highlight"],
      ],
      scale: "Ember scale",
    },

    type: {
      eyebrow: "Ch. 04 — Type",
      title: "Voices",
      lede: "Three families. One for editorial headlines, one for product body, one for code and technical marks.",
      display: "Display — Instrument Serif",
      displayUse: "Editorial headlines, pull-quotes, hero dataviz. Regular and italic only.",
      sans: "UI — Geist",
      sansUse: "Interface, body, microcopy. Weights 400-600.",
      mono: "Mono — JetBrains Mono",
      monoUse: "Code, technical marks, UI labels, tabular numerals.",
      sample: "The loom that holds your team together.",
      sampleAlt: "$ forge bootstrap --store=acme --model=./fga.json",
    },

    icons: {
      eyebrow: "Ch. 05 — Iconography",
      title: "Glyphs",
      lede: "One icon = one SDLC noun. 1.5px stroke, live corners, ember dot optional for active state.",
      grid: [
        ["forge", "Service", "service"],
        ["weave", "Fabric", "fabric"],
        ["anvil", "Pipeline", "build"],
        ["spark", "Deploy", "deploy"],
        ["plan",  "Model",  "model"],
        ["link",  "Relation", "rel"],
        ["seal",  "Policy", "policy"],
        ["scope", "Permit",  "permit"],
      ],
    },

    components: {
      eyebrow: "Ch. 06 — Components",
      title: "Parts",
      lede: "Parts are forged in the workshop; products assemble them.",
      buttons: "Buttons",
      badges: "Status badges",
      cards: "Cards & surfaces",
      code: "Code & terminals",
      spacing: "Spacing · 4u scale",
    },

    voice: {
      eyebrow: "Ch. 07 — Voice",
      title: "Tone",
      lede: "We talk like a senior engineer who can also write. Precise, direct, with a pinch of craft.",
      do: "We say it like this",
      dont: "Not like this",
      pairs: [
        ["Provision the store in 12 seconds.", "Revolutionizing authorization with AI magic."],
        ["Models are JSON. You version them as code.", "Next-generation synergistic platform."],
        ["If a service drops, another one picks up the hammer.", "Disruptive 360° resilience."],
      ],
      principles: [
        ["Specific, not generic", "“Bootstrap the store” beats “initial setup”."],
        ["Craft verbs", "Forge, weave, temper, seal. Never “orchestrate synergies”."],
        ["Bilingual", "Spanish as the team's home; English for the words of the craft."],
      ],
    },

    product: {
      eyebrow: "Ch. 08 — Product",
      title: "In use",
      lede: "The brand applied: the landing, the live service console, and a glimpse of the ReBAC model.",
      landingTitle: "Landing",
      landingHero: "One platform. Every SDLC role finds its thread.",
      landingSub: "Forge orchestrates services with Docker Compose and provisions OpenFGA stores and models before the first deploy. The rest of the team inherits permissions, env vars, and health checks already woven.",
      ctaPrimary: "Start the loom",
      ctaSecondary: "See the architecture",
      consoleTitle: "Service console",
      consoleSub: "Live compose view. Health checks woven into the permission model.",
      rebacTitle: "Relation model",
      rebacSub: "Declarative ReBAC, versioned as code. The graph is the contract.",
      metrics: [
        ["Healthy services", "23", "/24"],
        ["p95 latency", "84", "ms"],
        ["Permission checks", "1.2", "M/day"],
        ["Bootstraps today", "47", ""],
      ],
      services: [
        ["api-gateway",      "Ingress",      "ok",   "0.4%", "12ms"],
        ["fga-authz",        "Authorization","ok",   "0.1%", "3ms"],
        ["forge-bootstrap",  "Bootstrap",    "idle", "—",    "—"],
        ["compose-orchestrator", "Orchestration", "ok", "0.0%", "8ms"],
        ["postgres-fga",     "Data",         "ok",   "0.2%", "1ms"],
        ["billing-svc",      "Product",      "warn", "1.8%", "204ms"],
        ["telemetry-fluent", "Observability","ok",   "0.0%", "—"],
        ["cron-archiver",    "Data · batch", "err",  "—",    "—"],
      ],
    },

    closing: {
      title: "Keep the ",
      titleEm: "fire",
      titleAfter: " lit.",
      cols: [
        ["Curation", "Platform · Brand Squad · 2025-2026"],
        ["Type", "Instrument Serif · Geist · JetBrains Mono — Open Font License"],
        ["Contact", "brand@forge.platform"],
        ["Version", "v1.0 · 2026-05"],
      ],
    },

    tweaks: {
      title: "Tweaks",
      theme: "Theme",
      themeOpts: ["Light", "Dark"],
      density: "Density",
      densityOpts: ["Compact", "Comfortable", "Spacious"],
      mode: "Mode",
      modeOpts: ["GUI", "CLI"],
      lang: "Language",
      langOpts: ["ES", "EN"],
      accent: "Accent",
    },
  },
};

window.I18N = I18N;
