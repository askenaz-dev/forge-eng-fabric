/* portal-app.jsx — Forge Portal main React app
   Bilingual (ES/EN) Internal Developer Portal with system-default theme. */

/* global React, ReactDOM, PI, PORTAL_I18N, tFmt, NAV_GROUPS, RUNS, APPROVALS, ACTIVITY, SERVICES */

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ── Hooks ──────────────────────────────────────────────────────────────────
function useSystemDark() {
  const [dark, setDark] = useState(() =>
    typeof window !== "undefined" && window.matchMedia
      ? window.matchMedia("(prefers-color-scheme: dark)").matches
      : false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (e) => setDark(e.matches);
    mq.addEventListener?.("change", handler);
    return () => mq.removeEventListener?.("change", handler);
  }, []);
  return dark;
}

function useTheme() {
  // user preference: 'light' | 'dark' | 'system'
  const [pref, setPref] = useState(() => localStorage.getItem("forge_theme") || "system");
  const sysDark = useSystemDark();
  const effective = pref === "system" ? (sysDark ? "dark" : "light") : pref;
  const firstRun = useRef(true);
  useEffect(() => {
    const root = document.documentElement;
    // Guard against the shorthand-background transition leaving themed bgs in
    // limbo on the first toggle — disable all transitions for one frame while
    // we swap the theme attribute, then restore them.
    if (!firstRun.current) {
      root.setAttribute("data-theme-changing", "");
    }
    root.setAttribute("data-theme", effective);
    localStorage.setItem("forge_theme", pref);
    if (!firstRun.current) {
      // Two rAFs: let the browser commit one frame with no transitions,
      // then re-enable them so subsequent hovers animate normally.
      requestAnimationFrame(() => requestAnimationFrame(() => {
        root.removeAttribute("data-theme-changing");
      }));
    }
    firstRun.current = false;
  }, [pref, effective]);
  return [pref, setPref, effective];
}

function useLang() {
  const [lang, setLang] = useState(() => localStorage.getItem("forge_lang") || "es");
  useEffect(() => {
    localStorage.setItem("forge_lang", lang);
    document.documentElement.lang = lang;
  }, [lang]);
  const t = useCallback((key, vars) => {
    const dict = PORTAL_I18N[lang] || PORTAL_I18N.es;
    const raw = dict[key] ?? PORTAL_I18N.es[key] ?? key;
    return vars ? tFmt(raw, vars) : raw;
  }, [lang]);
  return [lang, setLang, t];
}

function useClickOutside(ref, onOut) {
  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) onOut(); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [ref, onOut]);
}

// ── Sidebar ────────────────────────────────────────────────────────────────
function Sidebar({ active, onPick, t }) {
  return (
    <aside className="side">
      <div className="side-brand">
        <svg className="mark" width="26" height="26" viewBox="0 0 32 32" fill="none">
          <path d="M6 4 H24 L26 6 V10 H22 V8 H10 V14 H20 V18 H10 V28 H6 Z" fill="currentColor" />
          <circle cx="25" cy="25" r="2.4" fill="var(--primary)" />
        </svg>
        <div className="wd">
          <span className="w">Forge</span>
          <span className="o">Engineering Fabric</span>
        </div>
        <span className="tenant" title="Tenant">
          <PI.diamond /> acme
        </span>
      </div>
      <nav className="side-nav">
        {NAV_GROUPS.map((g) => (
          <React.Fragment key={g.id}>
            <div className="side-section">{t(`nav_${g.id}`)}</div>
            {g.items.map((item) => {
              const Icon = PI[item.icon];
              return (
                <a key={item.id}
                   className={"side-link" + (active === item.id ? " active" : "")}
                   onClick={(e) => { e.preventDefault(); onPick(item.id); }}
                   href={`#${item.id}`}>
                  <Icon />
                  <span>{t(item.labelKey)}</span>
                  {item.count != null && <span className="ct">{item.count}</span>}
                </a>
              );
            })}
          </React.Fragment>
        ))}
      </nav>
      <div className="side-footer">
        <div className="ava">A</div>
        <div className="who">
          <b>Ana Restrepo</b>
          <small>{t("foot_role")}</small>
        </div>
        <button className="icon-btn" aria-label="More"><PI.more /></button>
      </div>
    </aside>
  );
}

// ── Theme menu ─────────────────────────────────────────────────────────────
function ThemeMenu({ pref, setPref, effective, t, onToast }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useClickOutside(ref, () => setOpen(false));
  const Icon = effective === "dark" ? PI.moon : PI.sun;
  const items = [
    { id: "light",  icon: PI.sun,     label: t("theme_light")  },
    { id: "dark",   icon: PI.moon,    label: t("theme_dark")   },
    { id: "system", icon: PI.monitor, label: t("theme_system"), hint: t("theme_system_hint") },
  ];
  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button className="icon-btn" aria-label={t("tb_theme")} onClick={() => setOpen(o => !o)}>
        <Icon />
      </button>
      {open && (
        <div className="pop">
          {items.map((it) => (
            <button key={it.id}
                    className={"pop-item" + (pref === it.id ? " active" : "")}
                    onClick={() => { setPref(it.id); setOpen(false); onToast(t("toast_theme")); }}>
              <it.icon className="lead" />
              <span>{it.label}</span>
              {it.hint && <small>{it.hint}</small>}
              {pref === it.id && <span className="check"><PI.check style={{ width: 13, height: 13 }} /></span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Top bar ────────────────────────────────────────────────────────────────
function TopBar({ pref, setPref, effective, lang, setLang, t, onToast, view }) {
  const isMac = typeof navigator !== "undefined" && /mac/i.test(navigator.platform);
  const kbd = isMac ? "⌘K" : "Ctrl K";
  return (
    <header className="top">
      <div className="top-crumb">
        <span>{t("crumb_workspace")}</span>
        <PI.chev className="sep" style={{ width: 12, height: 12 }} />
        <b>{t(`nav_${view}`)}</b>
      </div>
      <label className="top-search">
        <PI.search />
        <input placeholder={t("tb_search")} />
        <span className="kbd">{kbd}</span>
      </label>
      <div className="top-actions">
        <div className="lang-pill" role="group" aria-label={t("tb_lang")}>
          <button aria-pressed={lang === "es"}
                  onClick={() => { setLang("es"); onToast(PORTAL_I18N.es.toast_lang); }}>
            ES
          </button>
          <button aria-pressed={lang === "en"}
                  onClick={() => { setLang("en"); onToast(PORTAL_I18N.en.toast_lang_en); }}>
            EN
          </button>
        </div>
        <ThemeMenu pref={pref} setPref={setPref} effective={effective} t={t} onToast={onToast} />
        <button className="icon-btn" aria-label={t("tb_notif")}>
          <PI.bell />
          <span className="dot" />
        </button>
        <button className="icon-btn" aria-label="GitHub">
          <PI.github />
        </button>
      </div>
    </header>
  );
}

// ── KPI ────────────────────────────────────────────────────────────────────
function Spark({ data, color }) {
  const w = 110, h = 36, p = 4;
  const min = Math.min(...data), max = Math.max(...data);
  const span = max - min || 1;
  const pts = data.map((v, i) => {
    const x = p + (i * (w - p * 2)) / (data.length - 1);
    const y = h - p - ((v - min) / span) * (h - p * 2);
    return `${x},${y}`;
  });
  const area = `M ${pts[0]} L ${pts.join(" ")} L ${w - p},${h} L ${p},${h} Z`;
  const line = `M ${pts.join(" L ")}`;
  return (
    <svg className="spark" viewBox={`0 0 ${w} ${h}`}>
      <path d={area} fill={color} opacity="0.10" />
      <path d={line} stroke={color} strokeWidth="1.5" fill="none" />
    </svg>
  );
}

function KpiGrid({ t }) {
  const kpis = [
    { label: t("kpi_runs"),    icon: PI.workflows, num: "14", unit: null,
      delta: { dir: "up", v: "+22%" }, foot: t("kpi_vs"),
      data: [3,5,4,6,8,7,9,11,10,13,12,14], color: "var(--primary)" },
    { label: t("kpi_success"), icon: PI.check,     num: "98.4", unit: "%",
      delta: { dir: "up", v: "+0.6 pts" }, foot: t("kpi_vs"),
      data: [97,97.5,97.2,98,98.1,97.8,98.3,98.4,98.2,98.4,98.5,98.4], color: "var(--thread)" },
    { label: t("kpi_p95"),     icon: PI.clock,     num: "184", unit: "ms",
      delta: { dir: "down", v: "−18ms" }, foot: t("avg_today"),
      data: [220,212,205,200,196,210,202,194,188,190,186,184], color: "var(--info)" },
    { label: t("kpi_savings"), icon: PI.bolt,      num: "317", unit: "h",
      delta: { dir: "up", v: "+41h" }, foot: t("kpi_vs"),
      data: [180,210,205,240,260,250,280,290,300,295,310,317], color: "var(--copper)" },
  ];
  return (
    <div className="kpi-grid">
      {kpis.map((k, i) => (
        <div className="kpi" key={i}>
          <div className="lbl"><k.icon /><span>{k.label}</span></div>
          <div className="num">{k.num}{k.unit && <small> {k.unit}</small>}</div>
          <div className="foot">
            <span className={"delta " + (k.delta.dir === "up" ? "up" : "down")}>
              {k.delta.dir === "up" ? "▲" : "▼"} {k.delta.v}
            </span>
            <span>{k.foot}</span>
          </div>
          <Spark data={k.data} color={k.color} />
        </div>
      ))}
    </div>
  );
}

// ── Runs ───────────────────────────────────────────────────────────────────
function Runs({ t, onOpen, filter, setFilter }) {
  const filters = [
    { id: "all",     label: t("runs_filter_all"),     count: RUNS.length },
    { id: "running", label: t("runs_filter_running"), count: RUNS.filter(r=>r.status==="running").length },
    { id: "pending", label: t("runs_filter_wait"),    count: RUNS.filter(r=>r.status==="pending").length },
    { id: "success", label: t("runs_filter_succ"),    count: RUNS.filter(r=>r.status==="success").length },
    { id: "failed",  label: t("runs_filter_failed"),  count: RUNS.filter(r=>r.status==="failed").length },
  ];
  const visible = filter === "all" ? RUNS : RUNS.filter((r) => r.status === filter);

  const stClass = {
    running: "st--ok",
    success: "st--ok",
    failed:  "st--err",
    pending: "st--pending",
    queued:  "st--queued",
  };
  const stBadge = {
    running: <span className="badge badge--ok"><span className="dot" />{t("st_running")}</span>,
    success: <span className="badge badge--ok"><span className="dot" />{t("st_success")}</span>,
    failed:  <span className="badge badge--err"><span className="dot" />{t("st_failed")}</span>,
    pending: <span className="badge badge--warn"><span className="dot" />{t("st_pending")}</span>,
    queued:  <span className="badge"><span className="dot" style={{background:"var(--fg-3)"}} />{t("st_queued")}</span>,
  };
  return (
    <div className="card">
      <div className="card-hd">
        <div>
          <h3>{t("runs_title")}</h3>
          <div className="sub">{t("runs_sub")}</div>
        </div>
        <div className="right">
          <span className="live-now"><span className="lvd" /> {t("h_live")}</span>
          <button className="btn btn--ghost btn--xs"><PI.refresh /></button>
        </div>
      </div>
      <div className="chips">
        {filters.map((f) => (
          <button key={f.id} className="chip" aria-pressed={filter === f.id}
                  onClick={() => setFilter(f.id)}>
            {f.label}
            <span style={{ fontFamily: "var(--f-mono)", color: "var(--fg-3)" }}>{f.count}</span>
          </button>
        ))}
        <button className="btn btn--ghost btn--xs" style={{ marginLeft: "auto" }}>
          <PI.filter /> Filtros
        </button>
      </div>
      <div className="runs">
        {visible.map((r) => (
          <div className="run" key={r.id} onClick={() => onOpen(r)} style={{ cursor: "pointer" }}>
            <span className={"st " + (stClass[r.status] || "")} />
            <div className="agent">
              <div className="ai">{r.agentTag}</div>
              <div className="nm">
                {r.purpose}
                <small>{r.agent} · {r.id}</small>
              </div>
            </div>
            <div className="repo">{r.repo}</div>
            <div className="dur">{r.duration}</div>
            <div>{stBadge[r.status]}</div>
            <div className="pol">{r.policy}</div>
            <PI.chev className="chev" style={{ width: 14, height: 14 }} />
          </div>
        ))}
      </div>
      <div className="note" style={{ textAlign: "right" }}>
        <a href="#" onClick={(e)=>e.preventDefault()} style={{ color: "var(--primary)" }}>
          {t("runs_view_all")} →
        </a>
      </div>
    </div>
  );
}

// ── Approvals ──────────────────────────────────────────────────────────────
function Approvals({ t, lang, items, onAction }) {
  return (
    <div className="card">
      <div className="card-hd">
        <div>
          <h3>{t("apr_title")}</h3>
          <div className="sub">{t("apr_sub")}</div>
        </div>
        <span className="badge badge--ember"><span className="dot" />{items.length}</span>
      </div>
      {items.length === 0 ? (
        <div className="note" style={{ padding: "32px 18px", textAlign: "center" }}>
          {t("apr_no_items")}
        </div>
      ) : (
        items.map((a) => (
          <div className="approval" key={a.id}>
            <div className="approval-head">
              <div className="ai">{a.tag}</div>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div className="title">{a.title[lang]}</div>
                <div className="meta">{lang === "en" ? a.metaEn : a.meta}</div>
              </div>
              {a.severity === "high" && (
                <span className="badge badge--err"><span className="dot" />high</span>
              )}
            </div>
            <div className="approval-summary">
              <span className="add">+{a.deltaAdd}</span>
              {" / "}
              <span className="rem">−{a.deltaRem}</span>
              {" · "}
              {a.summary[lang]}
            </div>
            <div className="approval-actions">
              <button className="btn btn--primary btn--xs"
                      onClick={() => onAction("approve", a)}>
                <PI.check /> {t("apr_approve")}
              </button>
              <button className="btn btn--secondary btn--xs"
                      onClick={() => onAction("review", a)}>
                {t("apr_review")}
              </button>
              <button className="btn btn--ghost btn--xs"
                      onClick={() => onAction("reject", a)}>
                {t("apr_reject")}
              </button>
              <span className="timer">
                <PI.clock /> {t("apr_expires_in")} {a.expires}
              </span>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

// ── Activity timeline ──────────────────────────────────────────────────────
function Activity({ t, lang }) {
  const toneClass = { ok: "ic--ok", em: "ic--em", warn: "ic--warn", err: "ic--err" };
  return (
    <div className="card">
      <div className="card-hd">
        <div>
          <h3>{t("act_title")}</h3>
          <div className="sub">{t("act_sub")}</div>
        </div>
        <div className="right">
          <button className="btn btn--ghost btn--xs">{t("act_view")} →</button>
        </div>
      </div>
      <div className="timeline">
        {ACTIVITY.map((ev, i) => {
          const Icon = PI[ev.icon];
          // Render with bolded vars
          const raw = (PORTAL_I18N[lang] || PORTAL_I18N.es)[ev.evKey] || "";
          const parts = raw.split(/(\{\w+\})/g).map((seg, j) => {
            const m = seg.match(/^\{(\w+)\}$/);
            if (m) return <code key={j}>{ev.vars[m[1]]}</code>;
            return <React.Fragment key={j}>{seg}</React.Fragment>;
          });
          return (
            <div className="tl-row" key={i}>
              <div className={"ic " + (toneClass[ev.tone] || "")}><Icon /></div>
              <div className="body">
                <div className="txt">{parts}</div>
                <div className="meta">{ev.when}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Services mesh ──────────────────────────────────────────────────────────
function ServicesMesh({ t }) {
  // Lay services in a soft hub-spoke pattern around the orchestrator
  const center = { x: 220, y: 110 };
  const positions = {
    orchestrator: center,
    "policy-svc":  { x:  60, y:  40 },
    "openfga":     { x:  60, y: 110 },
    "registry":    { x:  60, y: 180 },
    "audit":       { x: 220, y: 200 },
    "context-eng": { x: 380, y: 180 },
    "spec-engine": { x: 380, y: 110 },
    "pgvector":    { x: 380, y:  40 },
  };
  return (
    <div className="card mesh-card">
      <div className="card-hd">
        <div>
          <h3>{t("svc_title")}</h3>
          <div className="sub">{t("svc_sub")}</div>
        </div>
        <div className="right">
          <span className="badge badge--ok"><span className="dot" />{SERVICES.filter(s=>s.state==="healthy").length} {t("svc_healthy")}</span>
          {SERVICES.some(s=>s.state==="degraded") && (
            <span className="badge badge--warn"><span className="dot" />1 {t("svc_degraded")}</span>
          )}
        </div>
      </div>
      <svg viewBox="0 0 440 220" preserveAspectRatio="xMidYMid meet">
        <defs>
          <radialGradient id="ringGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.18"/>
            <stop offset="60%" stopColor="var(--primary)" stopOpacity="0"/>
          </radialGradient>
        </defs>
        <circle cx={center.x} cy={center.y} r="80" fill="url(#ringGlow)" />
        {SERVICES.filter(s => s.id !== "orchestrator").map((s) => {
          const p = positions[s.id];
          if (!p) return null;
          const color = s.state === "healthy" ? "var(--thread)" : "var(--spark)";
          return (
            <g key={s.id}>
              <line x1={center.x} y1={center.y} x2={p.x} y2={p.y}
                    stroke="var(--border-strong)" strokeWidth="1" strokeDasharray="2 3" />
              <circle cx={p.x} cy={p.y} r="6" fill="var(--bg-card)" stroke={color} strokeWidth="1.5" />
              <circle cx={p.x} cy={p.y} r="2.5" fill={color}>
                <animate attributeName="opacity" values="0.4;1;0.4" dur="2.4s" repeatCount="indefinite" />
              </circle>
              <text x={p.x} y={p.y - 11} fontFamily="var(--f-mono)" fontSize="9"
                    fill="var(--fg-2)" textAnchor="middle" letterSpacing="0.04em">
                {s.id}
              </text>
            </g>
          );
        })}
        {/* hub */}
        <circle cx={center.x} cy={center.y} r="22" fill="var(--bg-card)"
                stroke="var(--primary)" strokeWidth="1.5" />
        <circle cx={center.x} cy={center.y} r="6" fill="var(--primary)" />
        <text x={center.x} y={center.y + 38} fontFamily="var(--f-mono)" fontSize="9.5"
              fill="var(--fg)" textAnchor="middle" letterSpacing="0.08em">
          ORCHESTRATOR
        </text>
      </svg>
      <div className="svc-grid">
        {SERVICES.slice(0, 4).map((s) => (
          <div className="svc-tile" key={s.id}>
            <div className="nm">{s.id}</div>
            <div className="kind">{t("svck_" + s.kind)}</div>
            <div className="met">
              <div className="ms">{s.rps}<small> rps</small></div>
              <span className={"badge " + (s.dot === "ok" ? "badge--ok" : "badge--warn")}>
                <span className="dot" />{s.p99}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Run detail sheet ───────────────────────────────────────────────────────
function RunSheet({ run, onClose, t }) {
  const stepTone = { ok: "ok", err: "err", em: "em", warn: "warn" };
  const steps = run.status === "failed" ? [
    { ic: "check", tone: "ok",  label: "registry.resolve(schema-migrator@2.1)", ms: "12ms" },
    { ic: "check", tone: "ok",  label: "openfga.check(actor=ana, action=migrate, resource=identity.users)", ms: "9ms" },
    { ic: "check", tone: "ok",  label: "policy.evaluate(schema.migrate.v1)", ms: "4ms" },
    { ic: "play",  tone: "em",  label: "tool.exec(postgres.alter_column type=citext)", ms: "—" },
    { ic: "x",     tone: "err", label: "constraint violation · idx_users_email_lower", ms: "1.0s" },
  ] : [
    { ic: "check", tone: "ok", label: "registry.resolve(review-bot@4.0)", ms: "11ms" },
    { ic: "check", tone: "ok", label: "openfga.check(actor=review-bot, action=read, resource=acme/payments-svc)", ms: "8ms" },
    { ic: "check", tone: "ok", label: "context.fetch(pr=4821, files=12)", ms: "240ms" },
    { ic: "play",  tone: "em", label: "skill.apply(review.deep · model=claude-sonnet-4.5)", ms: "running" },
  ];
  return (
    <div className="scrim" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-hd">
          <div>
            <div className="ttl"><em>{t("sheet_run")}</em> · {run.purpose}</div>
            <div className="sub" style={{ fontFamily: "var(--f-mono)", fontSize: 11.5,
                                          color: "var(--fg-3)", marginTop: 4 }}>
              {run.id} · {run.agent} · {run.repo}
            </div>
          </div>
          <button className="icon-btn" onClick={onClose}><PI.x /></button>
        </div>
        <div className="sheet-body">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, marginBottom: 18 }}>
            <div className="field" style={{ borderBottom: 0, padding: 0 }}>
              <span className="k">{t("triggered")}</span>
              <span className="v">{run.triggeredBy}</span>
            </div>
            <div className="field" style={{ borderBottom: 0, padding: 0 }}>
              <span className="k">{t("duration")}</span>
              <span className="v">{run.duration}</span>
            </div>
            <div className="field" style={{ borderBottom: 0, padding: 0 }}>
              <span className="k">{t("policy_short")}</span>
              <span className="v">{run.policy}</span>
            </div>
            <div className="field" style={{ borderBottom: 0, padding: 0 }}>
              <span className="k">{t("sheet_policy_pass")}</span>
              <span className="v tag">
                <span className="badge badge--info"><span className="dot" />{t("sheet_policy_eval")}</span>
              </span>
            </div>
          </div>

          <div style={{ marginTop: 6, marginBottom: 8, display: "flex", alignItems: "center", gap: 10 }}>
            <h4 style={{ margin: 0, fontFamily: "var(--f-display)", fontStyle: "italic",
                         fontSize: 18, fontWeight: 400, lineHeight: 1.2, whiteSpace: "nowrap" }}>
              {t("sheet_steps")}
            </h4>
            <span className="badge"><PI.clock /><span>{run.duration}</span></span>
          </div>
          <div style={{ background: "var(--bg-sunk)", borderRadius: "var(--r-3)",
                        padding: "10px 14px", fontFamily: "var(--f-mono)", fontSize: 12 }}>
            {steps.map((s, i) => {
              const Icon = PI[s.ic];
              const color = s.tone === "ok" ? "var(--thread)"
                          : s.tone === "err" ? "var(--rust)"
                          : s.tone === "em" ? "var(--primary)"
                          : "var(--spark)";
              return (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "18px 1fr auto",
                                       gap: 10, alignItems: "center", padding: "6px 0" }}>
                  <span style={{ color, display: "inline-flex" }}><Icon /></span>
                  <span style={{ color: "var(--fg)" }}>{s.label}</span>
                  <span style={{ color: "var(--fg-3)" }}>{s.ms}</span>
                </div>
              );
            })}
          </div>

          {run.status === "pending" && (
            <div style={{ marginTop: 18 }}>
              <h4 style={{ margin: "0 0 8px", fontFamily: "var(--f-display)", fontStyle: "italic",
                           fontSize: 18, fontWeight: 400, lineHeight: 1.2 }}>
                {t("sheet_diff_title")}
              </h4>
              <div className="diff">
                <div className="col">
                  <h5>{t("sheet_diff_before")}</h5>
                  <div className="line">replicas: 4</div>
                  <div className="line">image: orders-api:1.41.3</div>
                  <div className="line">resources.limits.memory: 512Mi</div>
                </div>
                <div className="col">
                  <h5>{t("sheet_diff_after")}</h5>
                  <div className="line">replicas: 6</div>
                  <div className="line add">image: orders-api:1.42.0</div>
                  <div className="line add">resources.limits.memory: 768Mi</div>
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="sheet-foot">
          <button className="btn btn--ghost" onClick={onClose}>{t("sheet_close")}</button>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn--secondary">
              <PI.copy /> {t("copy_id")}
            </button>
            {run.status === "pending" ? (
              <button className="btn btn--primary"><PI.check /> {t("sheet_approve_apply")}</button>
            ) : (
              <button className="btn btn--primary"><PI.external /> {t("open")}</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Toasts ─────────────────────────────────────────────────────────────────
function Toasts({ items }) {
  return (
    <div className="toast-wrap">
      {items.map((t) => (
        <div className="toast" key={t.id}>
          <PI.check /><span>{t.text}</span>
        </div>
      ))}
    </div>
  );
}

// ── Greeting ───────────────────────────────────────────────────────────────
function greeting(t) {
  const h = new Date().getHours();
  if (h < 12) return t("h_hello");
  if (h < 19) return t("h_hello_pm");
  return t("h_hello_n");
}

// ── App ────────────────────────────────────────────────────────────────────
function App() {
  const [pref, setPref, effective] = useTheme();
  const [lang, setLang, t] = useLang();
  const [view, setView] = useState("dashboard");
  const [filter, setFilter] = useState("all");
  const [run, setRun] = useState(null);
  const [approvals, setApprovals] = useState(APPROVALS);
  const [toasts, setToasts] = useState([]);

  const pushToast = useCallback((text) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((ts) => [...ts, { id, text }]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), 2400);
  }, []);

  const onApproval = (kind, a) => {
    if (kind === "review") {
      // Open as run-like
      setRun({
        id: a.id, status: "pending",
        agent: a.agent, agentTag: a.tag,
        purpose: a.title[lang],
        repo: lang === "en" ? a.metaEn : a.meta,
        duration: "—", policy: "policy.gate", triggeredBy: "agent",
      });
      return;
    }
    setApprovals((xs) => xs.filter((x) => x.id !== a.id));
    pushToast(kind === "approve" ? t("toast_approved") : t("toast_rejected"));
  };

  return (
    <div className="app">
      <Sidebar active={view} onPick={setView} t={t} />
      <TopBar pref={pref} setPref={setPref} effective={effective}
              lang={lang} setLang={setLang} t={t} onToast={pushToast} view={view} />
      <main className="main">
        <div className="main-inner">
          <div className="page-head">
            <div>
              <div style={{ fontFamily: "var(--f-mono)", fontSize: 11,
                            letterSpacing: ".12em", textTransform: "uppercase",
                            color: "var(--fg-3)", marginBottom: 8 }}>
                {greeting(t)} Ana
              </div>
              <h1 className="page-title">
                {t("h_overview_pre")} <em>{t("h_overview_em")}</em> {t("h_overview_post").split(".")[0]}.
              </h1>
              <p className="page-sub">{t("h_overview_post").split(".").slice(1).join(".").trim()}</p>
            </div>
            <div className="page-meta">
              <button className="btn btn--secondary"><PI.user /> {t("h_invite")}</button>
              <button className="btn btn--primary"><PI.plus /> {t("h_new_run")}</button>
            </div>
          </div>

          <KpiGrid t={t} />

          <div className="two-col">
            <div className="stack">
              <Runs t={t} onOpen={setRun} filter={filter} setFilter={setFilter} />
              <ServicesMesh t={t} />
            </div>
            <div className="stack">
              <Approvals t={t} lang={lang} items={approvals} onAction={onApproval} />
              <Activity t={t} lang={lang} />
            </div>
          </div>
        </div>
      </main>
      {run && <RunSheet run={run} onClose={() => setRun(null)} t={t} />}
      <Toasts items={toasts} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
