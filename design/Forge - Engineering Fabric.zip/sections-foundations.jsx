/* sections-foundations.jsx
   Cover · TOC · Manifesto · Identity · Color · Type
   Reads { t, cli } from props.
*/
/* global window, React, ForgeMark, I, WeavePattern */

// ── Cover ───────────────────────────────────────────────────────────────────
function Cover({ t }) {
  return (
    <section className="cover" id="ch-cover" data-screen-label="00 Cover">
      <WeavePattern />
      <div className="cover-meta" style={{ position: 'relative', zIndex: 2 }}>
        <div className="meta-block">
          <span>{t.cover.eyebrow}</span>
          <b>{t.cover.project}</b>
        </div>
        <div className="meta-block" style={{ textAlign: 'right' }}>
          <span>{t.cover.version}</span>
          <b>{t.cover.classification}</b>
        </div>
      </div>

      <div className="cover-display">
        <h1>
          <span>{t.cover.title1}</span>
          <br />
          <span className="stroke">{t.cover.title2}</span>
          <br />
          <span style={{ position: 'relative' }}>
            {t.cover.title3}
            <span style={{
              display: 'inline-block', width: '.4em', height: '.4em',
              borderRadius: '50%', background: 'var(--primary)',
              marginLeft: '.18em', verticalAlign: '.18em',
              boxShadow: '0 0 24px 4px color-mix(in oklch, var(--primary), transparent 40%)',
            }} />
          </span>
        </h1>
        <div className="cover-sub">
          <p className="cover-tagline">{t.cover.tagline}</p>
          <div style={{ textAlign: 'right' }}>
            <ForgeMark size={48} />
          </div>
        </div>
      </div>

      <div className="cover-foot" style={{ position: 'relative', zIndex: 2 }}>
        <span>{t.cover.foot1}</span>
        <span>{t.cover.foot2}</span>
        <span>{t.cover.foot3}</span>
      </div>
    </section>
  );
}

// ── Table of contents ──────────────────────────────────────────────────────
function TOC({ t }) {
  return (
    <section className="chapter" id="ch-toc" data-screen-label="00 Contents">
      <div className="chapter-num">
        <span>00</span>
        <span className="rule" />
        <span>{t.toc.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{t.toc.title}</h2>
      <p className="chapter-lede">{t.toc.lede}</p>

      <div className="toc">
        {t.toc.items.map(([n, ttl, sub]) => (
          <a key={n} href={`#ch-${n}`} className="toc-item">
            <span className="num">{n}</span>
            <span>
              <span className="ttl">{ttl}</span>
              <br />
              <span style={{ color: 'var(--fg-3)', fontSize: 13 }}>{sub}</span>
            </span>
            <span className="pg">p · {n}</span>
          </a>
        ))}
      </div>
    </section>
  );
}

// ── Manifesto ──────────────────────────────────────────────────────────────
function Manifesto({ t, cli }) {
  const m = t.manifesto;
  return (
    <section className="chapter alt" id="ch-01" data-screen-label="01 Manifesto">
      <div className="chapter-num">
        <span>01</span>
        <span className="rule" />
        <span>{m.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{m.title}</h2>
      <p className="chapter-lede">{m.lede}</p>

      <div style={{ height: 'var(--s-8)' }} />

      <p className="manifesto">
        <span className="dim">{m.quote[0]}</span>
        <em>{m.quote[1]}</em>
        <span className="dim">{m.quote[2]}</span>
      </p>

      <div style={{ height: 'var(--s-12)' }} />

      <div className="two-col">
        <div>
          <div className="h-eyebrow">Pilares · Pillars</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--s-3)', marginTop: 'var(--s-4)' }}>
            {m.pillars.map(([name, desc], i) => (
              <div key={i} style={{ borderTop: '1px solid var(--border)', paddingTop: 'var(--s-3)' }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
                  <span className="mono" style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.1em' }}>0{i+1}</span>
                  <span className="serif" style={{ fontStyle: 'italic', fontSize: 32, lineHeight: 1, color: 'var(--primary)' }}>{name}</span>
                </div>
                <p style={{ margin: '6px 0 0 0', color: 'var(--fg-2)', maxWidth: '38ch' }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
        <div>
          {m.body.map((p, i) => (
            <p key={i} className="body-text" style={{ marginTop: i === 0 ? 0 : 'var(--s-4)' }}>{p}</p>
          ))}

          {cli && (
            <div className="terminal" style={{ marginTop: 'var(--s-6)' }}>
              <div className="tbar">
                <span className="traffic" style={{ display:'inline-flex', gap:6 }}><i style={{display:'inline-block',width:10,height:10,borderRadius:'50%',background:'#3A332C'}}/><i style={{display:'inline-block',width:10,height:10,borderRadius:'50%',background:'#3A332C'}}/><i style={{display:'inline-block',width:10,height:10,borderRadius:'50%',background:'#3A332C'}}/></span>
                <span className="tab" style={{ marginLeft: 10 }}>~/forge/manifesto.md</span>
              </div>
              <div className="body">
                <div><span className="prompt">forge</span> <span className="dim">·</span> <span className="path">~</span> <span className="prompt">$</span> forge why</div>
                <div className="dim"># A loom, not a tool.</div>
                <div className="dim"># Threads are deliberate. Frames are forged.</div>
                <div><span className="prompt">forge</span> <span className="dim">·</span> <span className="path">~</span> <span className="prompt">$</span> <span className="cursor" /></div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

// ── Identity ───────────────────────────────────────────────────────────────
function Identity({ t }) {
  const k = t.identity;
  return (
    <section className="chapter" id="ch-02" data-screen-label="02 Identity">
      <div className="chapter-num">
        <span>02</span>
        <span className="rule" />
        <span>{k.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{k.title}</h2>
      <p className="chapter-lede">{k.lede}</p>

      <div className="two-col" style={{ marginTop: 'var(--s-8)' }}>
        <div>
          <div className="h-eyebrow">Construcción · Construction</div>
          <div className="constr" style={{ marginTop: 'var(--s-3)' }}>
            <span className="crosshair">grid · 14u</span>
            <ForgeMark size={168} />
          </div>
          <p className="body-text" style={{ marginTop: 'var(--s-3)', fontSize: 13 }}>{k.construction}</p>
        </div>

        <div>
          <div className="h-eyebrow">{k.lockups}</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--s-3)', marginTop: 'var(--s-3)' }}>
            <div className="logo-card">
              <span className="lbl">primary</span>
              <span className="logo">
                <ForgeMark size={32} />
                <span className="word">forge</span>
              </span>
            </div>
            <div className="logo-card inverse">
              <span className="lbl">inverse</span>
              <span className="logo" style={{ color: 'var(--paper)' }}>
                <ForgeMark size={32} />
                <span className="word">forge</span>
              </span>
            </div>
            <div className="logo-card ember">
              <span className="lbl">ember</span>
              <span className="logo" style={{ color: '#fff' }}>
                <ForgeMark size={32} ember={false} />
                <span className="word">forge</span>
              </span>
            </div>
            <div className="logo-card">
              <span className="lbl">mark only</span>
              <ForgeMark size={56} />
            </div>
          </div>

          <p className="body-text" style={{ marginTop: 'var(--s-4)', fontSize: 13 }}>{k.clear}</p>
        </div>
      </div>

      <div style={{ marginTop: 'var(--s-10)' }}>
        <div className="h-eyebrow">{k.misuseTitle}</div>
        <div className="grid-4" style={{ marginTop: 'var(--s-3)' }}>
          {[
            { rule: k.misuse[0], render: () => (
              <span className="logo" style={{ transform: 'scaleY(.6) scaleX(1.4)', transformOrigin: 'center' }}>
                <ForgeMark size={26} /><span className="word">forge</span>
              </span>
            )},
            { rule: k.misuse[1], render: () => (
              <span className="logo">
                <svg width="28" height="28" viewBox="0 0 32 32" fill="none">
                  <path d="M6 4 H24 L26 6 V10 H22 V8 H10 V14 H20 V18 H10 V28 H6 Z" fill="currentColor" />
                  <circle cx="25" cy="25" r="2.4" fill="#2A6FDB" />
                </svg>
                <span className="word">forge</span>
              </span>
            )},
            { rule: k.misuse[2], render: () => (
              <div style={{ background: 'linear-gradient(120deg, #E04416, #B7330F)', padding: '14px 18px', borderRadius: 6 }}>
                <span className="logo" style={{ color: '#DC4318' }}><ForgeMark size={26} ember={false} /><span className="word" style={{ color: '#DC4318' }}>forge</span></span>
              </div>
            )},
            { rule: k.misuse[3], render: () => (
              <span className="logo" style={{ transform: 'rotate(-12deg)' }}>
                <ForgeMark size={28} /><span className="word">forge</span>
              </span>
            )},
          ].map((row, i) => (
            <div key={i} className="misuse">
              <span className="x">✕</span>
              <span className="lbl">{row.rule}</span>
              {row.render()}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Color ──────────────────────────────────────────────────────────────────
function Color({ t }) {
  const k = t.color;
  const emberScale = [
    ['50',  '#FDEFE7'],
    ['100', '#FAD6BD'],
    ['200', '#F4A77E'],
    ['300', '#ED7C49'],
    ['400', '#E45A24'],
    ['500', '#DC4318'],
    ['600', '#B7330F'],
    ['700', '#8A2509'],
    ['800', '#5C1A06'],
    ['900', '#2E0D03'],
  ];
  const neutrals = [
    ['Paper',   '#F5F1E9', true,  'background'],
    ['Paper-2', '#EFE9DD', true,  'surface'],
    ['Hair',    '#D9D2C5', true,  'border'],
    ['Mute',    '#9C9489', true,  'fg-3'],
    ['Slate',   '#6B6157', false, 'fg-2'],
    ['Ink',     '#13110F', false, 'fg'],
  ];
  const semColors = {
    thread: '#4F8C76',
    spark:  '#E8B100',
    rust:   '#B33620',
    steel:  '#243441',
    copper: '#B57340',
  };

  return (
    <section className="chapter alt" id="ch-03" data-screen-label="03 Color">
      <div className="chapter-num">
        <span>03</span>
        <span className="rule" />
        <span>{k.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{k.title}</h2>
      <p className="chapter-lede">{k.lede}</p>

      <div style={{ marginTop: 'var(--s-8)' }}>
        <div className="h-eyebrow">{k.primary}</div>
        <div className="grid-3" style={{ marginTop: 'var(--s-3)', alignItems: 'stretch' }}>
          <div className="swatch is-dark"
               style={{ background: '#DC4318', minHeight: 220, gridColumn: 'span 2' }}>
            <div className="role">Brasa · Ember · 500</div>
            <div>
              <div className="name" style={{ fontSize: 56, color: '#fff' }}>Ember</div>
              <div style={{ fontFamily: 'var(--f-mono)', fontSize: 12, opacity: .85, marginTop: 6 }}>
                Acción · CTA · acento editorial · estado activo
              </div>
            </div>
            <div className="hex"><span>#DC4318</span><span>oklch(58% .18 36)</span></div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--s-2)' }}>
            <div className="swatch is-light" style={{ background: '#F5F1E9', minHeight: 100 }}>
              <div className="role">Paper · Base</div>
              <div className="hex"><span>#F5F1E9</span></div>
            </div>
            <div className="swatch is-dark" style={{ background: '#13110F', minHeight: 100 }}>
              <div className="role">Ink · Tinta</div>
              <div className="hex"><span>#13110F</span></div>
            </div>
          </div>
        </div>

        <div style={{ marginTop: 'var(--s-6)' }}>
          <div className="scale-row">
            <div className="label">{k.scale}</div>
            <div className="scale-strip">
              {emberScale.map(([n, hex], i) => (
                <div key={n} style={{ background: hex, color: i < 5 ? '#13110F' : '#FDEFE7' }}>
                  <span style={{ opacity: .85 }}>{n}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 'var(--s-10)' }}>
        <div className="h-eyebrow">{k.neutrals}</div>
        <div className="grid-3" style={{ marginTop: 'var(--s-3)' }}>
          {neutrals.map(([nm, hex, light, role]) => (
            <div key={nm} className={`swatch ${light ? 'is-light' : 'is-dark'}`}
                 style={{ background: hex, minHeight: 140 }}>
              <div className="role">{role}</div>
              <div>
                <div className="name">{nm}</div>
              </div>
              <div className="hex"><span>{hex}</span></div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 'var(--s-10)' }}>
        <div className="h-eyebrow">{k.semantic}</div>
        <p className="body-text" style={{ marginTop: 4, marginBottom: 'var(--s-4)' }}>{k.semanticDesc}</p>
        <div className="surface" style={{ padding: '0 var(--s-5)' }}>
          {k.semanticItems.map(([key, nm, use]) => (
            <div key={key} className="semantic-row">
              <span className="chip" style={{ background: semColors[key] }} />
              <span className="nm">{nm}</span>
              <span className="use">{use}</span>
              <span className="val">--{key} · {semColors[key]}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Typography ─────────────────────────────────────────────────────────────
function Type({ t }) {
  const k = t.type;
  return (
    <section className="chapter" id="ch-04" data-screen-label="04 Type">
      <div className="chapter-num">
        <span>04</span>
        <span className="rule" />
        <span>{k.eyebrow}</span>
      </div>
      <h2 className="chapter-title">{k.title}</h2>
      <p className="chapter-lede">{k.lede}</p>

      <div style={{ marginTop: 'var(--s-8)' }}>
        {/* Display */}
        <div className="type-specimen">
          <div className="type-meta">
            <span><b>{k.display}</b></span>
            <span>400 · italic</span>
          </div>
          <p className="type-show serif" style={{ fontSize: 'clamp(48px, 7vw, 96px)' }}>
            <span>El telar </span>
            <em style={{ color: 'var(--primary)' }}>que sostiene</em>
            <span> a tu equipo.</span>
          </p>
          <div className="type-scale">
            <div className="row">
              <span className="px">96/88</span>
              <span className="specimen serif" style={{ fontSize: 56, letterSpacing: '-0.02em' }}>Forge</span>
              <span className="px">DISPLAY</span>
            </div>
            <div className="row">
              <span className="px">48/52</span>
              <span className="specimen serif" style={{ fontSize: 36 }}>Forjar el bastidor</span>
              <span className="px">CHAPTER</span>
            </div>
            <div className="row">
              <span className="px">28/36</span>
              <span className="specimen serif" style={{ fontSize: 22, fontStyle: 'italic' }}>Una plataforma es un telar.</span>
              <span className="px">PULL-QUOTE</span>
            </div>
          </div>
          <p style={{ marginTop: 'var(--s-4)', color: 'var(--fg-2)', fontSize: 13 }}>{k.displayUse}</p>
        </div>

        {/* Sans */}
        <div className="type-specimen">
          <div className="type-meta">
            <span><b>{k.sans}</b></span>
            <span>400 · 500 · 600</span>
          </div>
          <p className="type-show" style={{ fontFamily: 'var(--f-sans)', fontSize: 'clamp(36px, 4vw, 52px)', fontWeight: 500, letterSpacing: '-0.02em' }}>
            ABCDEFGHIJKLMNÑOPQRSTUVWXYZ
            <br />
            0123456789 · @#%*/&·—→
          </p>
          <div className="type-scale">
            <div className="row">
              <span className="px">24/32</span>
              <span className="specimen" style={{ fontSize: 24, fontWeight: 500 }}>El bootstrap aprovisiona el store.</span>
              <span className="px">H2 · 500</span>
            </div>
            <div className="row">
              <span className="px">16/24</span>
              <span className="specimen" style={{ fontSize: 16 }}>Cuerpo. Forge orquesta servicios y mantiene el modelo de permisos como código.</span>
              <span className="px">BODY · 400</span>
            </div>
            <div className="row">
              <span className="px">13/18</span>
              <span className="specimen" style={{ fontSize: 13, color: 'var(--fg-2)' }}>Microcopy. Detalles, ayudas y metadatos.</span>
              <span className="px">SMALL · 400</span>
            </div>
          </div>
          <p style={{ marginTop: 'var(--s-4)', color: 'var(--fg-2)', fontSize: 13 }}>{k.sansUse}</p>
        </div>

        {/* Mono */}
        <div className="type-specimen">
          <div className="type-meta">
            <span><b>{k.mono}</b></span>
            <span>400 · 500</span>
          </div>
          <p className="type-show mono" style={{ fontSize: 'clamp(20px, 2.4vw, 32px)', letterSpacing: 0, fontWeight: 500 }}>
            {k.sampleAlt}
          </p>
          <div className="type-scale">
            <div className="row">
              <span className="px">14/22</span>
              <span className="specimen mono" style={{ fontSize: 14 }}>compose up forge --profile=engineering</span>
              <span className="px">CODE</span>
            </div>
            <div className="row">
              <span className="px">11/16</span>
              <span className="specimen mono" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--fg-2)' }}>chapter · section · label</span>
              <span className="px">LABEL</span>
            </div>
            <div className="row">
              <span className="px">12/18</span>
              <span className="specimen mono" style={{ fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>23 / 24 · 84ms · 1.2M/día · v1.0.0</span>
              <span className="px">METRIC</span>
            </div>
          </div>
          <p style={{ marginTop: 'var(--s-4)', color: 'var(--fg-2)', fontSize: 13 }}>{k.monoUse}</p>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { Cover, TOC, Manifesto, Identity, Color, Type });
