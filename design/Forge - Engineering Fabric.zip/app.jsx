/* app.jsx — Forge brand notebook root */
/* global window, React, ReactDOM,
   useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakColor, TweakSelect,
   ForgeMark, I, WeavePattern,
   Cover, TOC, Manifesto, Identity, Color, Type,
   Icons, Components, Voice, Product, Closing */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "density": "comfortable",
  "mode": "gui",
  "lang": "es",
  "accent": "#DC4318"
}/*EDITMODE-END*/;

function Chrome({ t, lang, setLang, accent }) {
  return (
    <header className="site-chrome">
      <a href="#ch-cover" className="logo">
        <ForgeMark size={22} />
        <span className="word">forge</span>
      </a>
      <nav>
        <a href="#ch-01">{t.nav.foundations}</a>
        <a href="#ch-02">{t.nav.identity}</a>
        <a href="#ch-03">{t.nav.color}</a>
        <a href="#ch-04">{t.nav.type}</a>
        <a href="#ch-05">{t.nav.icons}</a>
        <a href="#ch-06">{t.nav.components}</a>
        <a href="#ch-07">{t.nav.voice}</a>
        <a href="#ch-08">{t.nav.product}</a>
      </nav>
      <span className="lang-pill">
        <button aria-pressed={lang === 'es'} onClick={() => setLang('es')}>ES</button>
        <button aria-pressed={lang === 'en'} onClick={() => setLang('en')}>EN</button>
      </span>
    </header>
  );
}

function App() {
  const [tw, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const lang = tw.lang === 'en' ? 'en' : 'es';
  const t = window.I18N[lang];
  const cli = tw.mode === 'cli';

  React.useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', tw.theme);
    root.setAttribute('data-density', tw.density);
    root.style.setProperty('--primary', tw.accent);
    root.style.setProperty('--ember-500', tw.accent);
  }, [tw.theme, tw.density, tw.accent]);

  const setLang = (l) => setTweak('lang', l);

  return (
    <div className="book">
      <Chrome t={t} lang={lang} setLang={setLang} accent={tw.accent} />
      <Cover t={t} />
      <TOC t={t} />
      <Manifesto t={t} cli={cli} />
      <Identity t={t} />
      <Color t={t} />
      <Type t={t} />
      <Icons t={t} />
      <Components t={t} cli={cli} />
      <Voice t={t} />
      <Product t={t} cli={cli} theme={tw.theme} />
      <Closing t={t} />

      <TweaksPanel title={t.tweaks.title}>
        <TweakSection label={t.tweaks.theme}>
          <TweakRadio label={t.tweaks.theme} value={tw.theme}
            options={[{value:'light',label:t.tweaks.themeOpts[0]},{value:'dark',label:t.tweaks.themeOpts[1]}]}
            onChange={(v) => setTweak('theme', v)} />
        </TweakSection>
        <TweakSection label={t.tweaks.density}>
          <TweakRadio label={t.tweaks.density} value={tw.density}
            options={[
              {value:'compact',label:t.tweaks.densityOpts[0]},
              {value:'comfortable',label:t.tweaks.densityOpts[1]},
              {value:'spacious',label:t.tweaks.densityOpts[2]},
            ]}
            onChange={(v) => setTweak('density', v)} />
        </TweakSection>
        <TweakSection label={t.tweaks.mode}>
          <TweakRadio label={t.tweaks.mode} value={tw.mode}
            options={[{value:'gui',label:'GUI'},{value:'cli',label:'CLI'}]}
            onChange={(v) => setTweak('mode', v)} />
        </TweakSection>
        <TweakSection label={t.tweaks.lang}>
          <TweakRadio label={t.tweaks.lang} value={tw.lang}
            options={[{value:'es',label:'ES'},{value:'en',label:'EN'}]}
            onChange={(v) => setTweak('lang', v)} />
        </TweakSection>
        <TweakSection label={t.tweaks.accent}>
          <TweakColor label={t.tweaks.accent} value={tw.accent}
            options={['#DC4318', '#B7330F', '#E45A24', '#243441', '#4F8C76']}
            onChange={(v) => setTweak('accent', v)} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
