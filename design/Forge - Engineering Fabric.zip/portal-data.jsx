/* portal-data.jsx — Forge Portal mock data + bilingual i18n
   Realistic SDLC platform fixtures: agents (Temporal-orchestrated), MCP tools,
   skills, workflow runs, approval queue, audit timeline, services. */

/* global window */

// ────────────────────────────────────────────────────────────────────────────
// I18N
// ────────────────────────────────────────────────────────────────────────────
const I18N = {
  es: {
    // Nav
    nav_platform: "Plataforma",
    nav_govern: "Gobierno",
    nav_observe: "Observabilidad",
    nav_account: "Cuenta",
    nav_dashboard: "Tablero",
    nav_agents: "Agentes",
    nav_skills: "Skills",
    nav_mcp: "Herramientas MCP",
    nav_workflows: "Workflows",
    nav_approvals: "Aprobaciones",
    nav_specs: "Specs (OpenSpec)",
    nav_policies: "Políticas (OPA)",
    nav_audit: "Auditoría",
    nav_obs: "Métricas y trazas",
    nav_settings: "Ajustes",

    // Top bar
    tb_search: "Buscar agentes, runs, skills, specs…",
    tb_search_short: "Buscar…",
    tb_notif: "Notificaciones",
    tb_theme: "Tema",
    tb_lang: "Idioma",

    // Theme
    theme_light: "Claro",
    theme_dark: "Oscuro",
    theme_system: "Sistema",
    theme_system_hint: "Sigue al SO",

    // Crumbs
    crumb_workspace: "Workspace · Engineering",
    crumb_dashboard: "Tablero",

    // Page head
    h_hello: "Buenos días,",
    h_hello_pm: "Buenas tardes,",
    h_hello_n: "Buenas noches,",
    h_overview_em: "telar",
    h_overview_pre: "Tu",
    h_overview_post: "está corriendo en caliente. 14 agentes activos, 3 aprobaciones esperándote.",
    h_new_run: "Lanzar workflow",
    h_invite: "Invitar equipo",
    h_live: "en vivo · refresca cada 2s",

    // KPIs
    kpi_runs: "Runs en curso",
    kpi_success: "Éxito 24 h",
    kpi_p95: "p95 latencia",
    kpi_savings: "Horas ahorradas / semana",
    kpi_vs: "vs semana pasada",

    // Runs
    runs_title: "Runs recientes",
    runs_sub: "últimos 50 · todas las branches",
    runs_filter_all: "Todos",
    runs_filter_running: "Corriendo",
    runs_filter_succ: "Exitosos",
    runs_filter_failed: "Fallidos",
    runs_filter_wait: "Esperando aprobación",
    runs_view_all: "Ver todos",

    st_running: "Corriendo",
    st_success: "OK",
    st_failed: "Fallido",
    st_pending: "Aprobación",
    st_queued: "En cola",

    // Approvals
    apr_title: "Cola de aprobación",
    apr_sub: "Human-in-the-loop · OPA",
    apr_approve: "Aprobar",
    apr_reject: "Rechazar",
    apr_review: "Revisar",
    apr_expires_in: "vence en",
    apr_no_items: "Sin aprobaciones pendientes.",

    // Activity
    act_title: "Actividad de la plataforma",
    act_sub: "eventos firmados · audit-log",
    act_view: "Ver auditoría",

    // Services mesh
    svc_title: "Mesh de servicios",
    svc_sub: "Temporal · OPA · OpenFGA · pgvector",
    svc_healthy: "sano",
    svc_degraded: "degradado",

    // Service kinds
    svck_orch: "Orquestación",
    svck_policy: "Política",
    svck_authz: "AuthZ",
    svck_registry: "Registro",
    svck_audit: "Auditoría",
    svck_ctx: "Contexto",
    svck_spec: "Specs",
    svck_db: "Datos",

    // Sheet (run detail)
    sheet_run: "Run",
    sheet_input: "Entrada",
    sheet_steps: "Pasos del workflow",
    sheet_policy_eval: "Evaluación de política",
    sheet_policy_pass: "Permitido por",
    sheet_diff_title: "Diff propuesto",
    sheet_diff_before: "Antes",
    sheet_diff_after: "Después",
    sheet_close: "Cerrar",
    sheet_approve_apply: "Aprobar y aplicar",
    sheet_request_changes: "Pedir cambios",

    // Toast
    toast_approved: "Aprobado. El agente continúa la ejecución.",
    toast_rejected: "Rechazado. Se notificó al agente.",
    toast_lang: "Idioma cambiado a Español",
    toast_lang_en: "Idioma cambiado a Inglés",
    toast_theme: "Tema actualizado",

    // Cmd palette hint
    cmd_hint: "para ir a cualquier sitio",

    // Footer
    foot_role: "Plataforma · Ingeniero",
    invite_lbl: "Invitar",

    // Misc
    every: "cada",
    secs: "s",
    avg_today: "promedio hoy",
    by: "por",
    in_branch: "en",
    triggered: "lanzado por",
    duration: "duración",
    policy_short: "OPA",
    open: "Abrir",
    copy_id: "Copiar ID",

    // Activity events (template-style with placeholders {name})
    ev_run_started: "El agente {agent} inició un run en {repo}",
    ev_apr_granted: "Aprobado el cambio sobre {target} por {who}",
    ev_policy_denied: "Política {policy} bloqueó la herramienta {tool}",
    ev_skill_pub: "Nueva skill {skill} publicada por {who}",
    ev_self_heal: "Self-healing reinició {service} tras 3 errores 5xx",
    ev_spec_merged: "Spec {spec} mergeada · contratos actualizados",
  },
  en: {
    nav_platform: "Platform",
    nav_govern: "Governance",
    nav_observe: "Observability",
    nav_account: "Account",
    nav_dashboard: "Dashboard",
    nav_agents: "Agents",
    nav_skills: "Skills",
    nav_mcp: "MCP Tools",
    nav_workflows: "Workflows",
    nav_approvals: "Approvals",
    nav_specs: "Specs (OpenSpec)",
    nav_policies: "Policies (OPA)",
    nav_audit: "Audit log",
    nav_obs: "Metrics & traces",
    nav_settings: "Settings",

    tb_search: "Search agents, runs, skills, specs…",
    tb_search_short: "Search…",
    tb_notif: "Notifications",
    tb_theme: "Theme",
    tb_lang: "Language",

    theme_light: "Light",
    theme_dark: "Dark",
    theme_system: "System",
    theme_system_hint: "Follow OS",

    crumb_workspace: "Workspace · Engineering",
    crumb_dashboard: "Dashboard",

    h_hello: "Good morning,",
    h_hello_pm: "Good afternoon,",
    h_hello_n: "Good evening,",
    h_overview_em: "loom",
    h_overview_pre: "Your",
    h_overview_post: "is running hot. 14 agents active, 3 approvals waiting on you.",
    h_new_run: "Launch workflow",
    h_invite: "Invite team",
    h_live: "live · refreshes every 2s",

    kpi_runs: "Runs in progress",
    kpi_success: "Success 24 h",
    kpi_p95: "p95 latency",
    kpi_savings: "Hours saved / week",
    kpi_vs: "vs last week",

    runs_title: "Recent runs",
    runs_sub: "last 50 · all branches",
    runs_filter_all: "All",
    runs_filter_running: "Running",
    runs_filter_succ: "Succeeded",
    runs_filter_failed: "Failed",
    runs_filter_wait: "Waiting on approval",
    runs_view_all: "View all",

    st_running: "Running",
    st_success: "OK",
    st_failed: "Failed",
    st_pending: "Approval",
    st_queued: "Queued",

    apr_title: "Approval queue",
    apr_sub: "Human-in-the-loop · OPA",
    apr_approve: "Approve",
    apr_reject: "Reject",
    apr_review: "Review",
    apr_expires_in: "expires in",
    apr_no_items: "No pending approvals.",

    act_title: "Platform activity",
    act_sub: "signed events · audit-log",
    act_view: "View audit",

    svc_title: "Service mesh",
    svc_sub: "Temporal · OPA · OpenFGA · pgvector",
    svc_healthy: "healthy",
    svc_degraded: "degraded",

    svck_orch: "Orchestration",
    svck_policy: "Policy",
    svck_authz: "AuthZ",
    svck_registry: "Registry",
    svck_audit: "Audit",
    svck_ctx: "Context",
    svck_spec: "Specs",
    svck_db: "Data",

    sheet_run: "Run",
    sheet_input: "Input",
    sheet_steps: "Workflow steps",
    sheet_policy_eval: "Policy evaluation",
    sheet_policy_pass: "Allowed by",
    sheet_diff_title: "Proposed diff",
    sheet_diff_before: "Before",
    sheet_diff_after: "After",
    sheet_close: "Close",
    sheet_approve_apply: "Approve & apply",
    sheet_request_changes: "Request changes",

    toast_approved: "Approved. Agent will resume execution.",
    toast_rejected: "Rejected. Agent has been notified.",
    toast_lang: "Language switched to Spanish",
    toast_lang_en: "Language switched to English",
    toast_theme: "Theme updated",

    cmd_hint: "to navigate anywhere",

    foot_role: "Platform · Engineer",
    invite_lbl: "Invite",

    every: "every",
    secs: "s",
    avg_today: "today's avg",
    by: "by",
    in_branch: "on",
    triggered: "triggered by",
    duration: "duration",
    policy_short: "OPA",
    open: "Open",
    copy_id: "Copy ID",

    ev_run_started: "Agent {agent} started a run on {repo}",
    ev_apr_granted: "Approved change on {target} by {who}",
    ev_policy_denied: "Policy {policy} blocked tool {tool}",
    ev_skill_pub: "New skill {skill} published by {who}",
    ev_self_heal: "Self-healing restarted {service} after 3 × 5xx",
    ev_spec_merged: "Spec {spec} merged · contracts updated",
  },
};

const tFmt = (str, vars) => str.replace(/\{(\w+)\}/g, (_, k) => vars?.[k] ?? "");

// ────────────────────────────────────────────────────────────────────────────
// MOCK DATA
// ────────────────────────────────────────────────────────────────────────────
const NAV_GROUPS = [
  {
    id: "platform",
    items: [
      { id: "dashboard", icon: "home", labelKey: "nav_dashboard" },
      { id: "agents",    icon: "agents", labelKey: "nav_agents", count: 14 },
      { id: "skills",    icon: "skills", labelKey: "nav_skills", count: 47 },
      { id: "mcp",       icon: "mcp", labelKey: "nav_mcp", count: 22 },
      { id: "workflows", icon: "workflows", labelKey: "nav_workflows" },
    ],
  },
  {
    id: "govern",
    items: [
      { id: "approvals", icon: "approvals", labelKey: "nav_approvals", count: 3 },
      { id: "specs",     icon: "specs", labelKey: "nav_specs" },
      { id: "policies",  icon: "policy", labelKey: "nav_policies" },
      { id: "audit",     icon: "audit", labelKey: "nav_audit" },
    ],
  },
  {
    id: "observe",
    items: [
      { id: "obs",       icon: "obs", labelKey: "nav_obs" },
    ],
  },
  {
    id: "account",
    items: [
      { id: "settings",  icon: "settings", labelKey: "nav_settings" },
    ],
  },
];

const RUNS = [
  { id: "wf_8a13c2", status: "running",  agent: "review-bot",         agentTag: "AR",
    purpose: "Review · PR #4821 · payments-svc",
    repo: "acme/payments-svc · main",
    duration: "00:48", policy: "review.v3", triggeredBy: "ana@acme.io" },
  { id: "wf_8a13c1", status: "pending",  agent: "deploy-conductor",   agentTag: "DC",
    purpose: "Deploy v1.42.0 → prod",
    repo: "acme/orders-api · release/1.42",
    duration: "12:04", policy: "deploy.prod.v2", triggeredBy: "ana@acme.io" },
  { id: "wf_8a13c0", status: "success",  agent: "spec-drafter",       agentTag: "SD",
    purpose: "Draft spec for /v3/refunds",
    repo: "acme/specs · feat/refunds-v3",
    duration: "02:11", policy: "spec.draft.v1", triggeredBy: "liu@acme.io" },
  { id: "wf_8a13bf", status: "success",  agent: "test-mason",         agentTag: "TM",
    purpose: "Generate integration tests",
    repo: "acme/checkout · feat/3ds-auth",
    duration: "06:33", policy: "test.gen.v2", triggeredBy: "ci-bot" },
  { id: "wf_8a13be", status: "failed",   agent: "schema-migrator",    agentTag: "SM",
    purpose: "Migrate users.email → citext",
    repo: "acme/identity · hotfix/email-case",
    duration: "01:09", policy: "schema.migrate.v1", triggeredBy: "marco@acme.io" },
  { id: "wf_8a13bd", status: "running",  agent: "code-reviewer-deep", agentTag: "CR",
    purpose: "Deep review · 4 files",
    repo: "acme/risk-engine · feat/anomaly",
    duration: "00:21", policy: "review.deep.v1", triggeredBy: "ines@acme.io" },
  { id: "wf_8a13bc", status: "queued",   agent: "doc-weaver",         agentTag: "DW",
    purpose: "Publish runbook · refunds",
    repo: "acme/runbooks · main",
    duration: "—", policy: "doc.publish.v1", triggeredBy: "scheduler" },
  { id: "wf_8a13bb", status: "success",  agent: "obs-tailor",         agentTag: "OB",
    purpose: "Add SLO dashboard · payments",
    repo: "acme/observability · main",
    duration: "03:50", policy: "obs.slo.v1", triggeredBy: "ana@acme.io" },
];

const APPROVALS = [
  {
    id: "apr_2401",
    agent: "deploy-conductor",
    tag: "DC",
    title: { es: "Desplegar orders-api v1.42.0 a producción",
             en: "Deploy orders-api v1.42.0 to production" },
    meta: "run · wf_8a13c1 · release/1.42 · 12 servicios",
    metaEn: "run · wf_8a13c1 · release/1.42 · 12 services",
    summary: {
      es: "Migración de schema + restart rolling · canary 5% por 10 min",
      en: "Schema migration + rolling restart · canary 5% for 10 min",
    },
    deltaAdd: 18,
    deltaRem: 4,
    expires: "27:14",
    severity: "high",
  },
  {
    id: "apr_2402",
    agent: "schema-migrator",
    tag: "SM",
    title: { es: "Cambio destructivo: DROP COLUMN users.legacy_id",
             en: "Destructive change: DROP COLUMN users.legacy_id" },
    meta: "run · wf_8a13ba · main · 1 tabla",
    metaEn: "run · wf_8a13ba · main · 1 table",
    summary: {
      es: "Columna sin lectura en 90 días · backfill verificado",
      en: "Column unread for 90 days · backfill verified",
    },
    deltaAdd: 0,
    deltaRem: 1,
    expires: "01:42",
    severity: "high",
  },
  {
    id: "apr_2403",
    agent: "policy-curator",
    tag: "PC",
    title: { es: "Permitir herramienta MCP filesystem.write a code-reviewer-deep",
             en: "Grant MCP tool filesystem.write to code-reviewer-deep" },
    meta: "policy · review.deep.v1 · scoped to /tmp",
    metaEn: "policy · review.deep.v1 · scoped to /tmp",
    summary: {
      es: "Sólo dentro de sandbox · revocable · max 5 MiB por escritura",
      en: "Sandbox only · revocable · max 5 MiB per write",
    },
    deltaAdd: 3,
    deltaRem: 0,
    expires: "1d 04h",
    severity: "low",
  },
];

const ACTIVITY = [
  { kind: "run",    icon: "play",     evKey: "ev_run_started",
    vars: { agent: "review-bot", repo: "acme/payments-svc" },
    when: "08:42:18", tone: "em" },
  { kind: "apr",    icon: "approvals", evKey: "ev_apr_granted",
    vars: { target: "acme/checkout · 3DS auth", who: "liu@acme.io" },
    when: "08:39:02", tone: "ok" },
  { kind: "policy", icon: "shield",   evKey: "ev_policy_denied",
    vars: { policy: "tool.allowlist.v2", tool: "shell.exec" },
    when: "08:37:55", tone: "warn" },
  { kind: "skill",  icon: "skills",  evKey: "ev_skill_pub",
    vars: { skill: "extract-pii@1.4.0", who: "marco@acme.io" },
    when: "08:34:11", tone: "default" },
  { kind: "heal",   icon: "bolt",    evKey: "ev_self_heal",
    vars: { service: "context-engine" },
    when: "08:29:30", tone: "warn" },
  { kind: "spec",   icon: "specs",   evKey: "ev_spec_merged",
    vars: { spec: "v3.refunds.openspec" },
    when: "08:21:09", tone: "ok" },
];

const SERVICES = [
  { id: "orchestrator", kind: "orch",    state: "healthy",  rps: 218, p99: "82ms",  dot: "ok" },
  { id: "policy-svc",   kind: "policy",  state: "healthy",  rps: 1240, p99: "9ms",  dot: "ok" },
  { id: "openfga",      kind: "authz",   state: "healthy",  rps: 980,  p99: "11ms", dot: "ok" },
  { id: "registry",     kind: "registry",state: "healthy",  rps: 88,   p99: "24ms", dot: "ok" },
  { id: "audit",        kind: "audit",   state: "healthy",  rps: 412,  p99: "16ms", dot: "ok" },
  { id: "context-eng",  kind: "ctx",     state: "degraded", rps: 64,   p99: "320ms", dot: "warn" },
  { id: "spec-engine",  kind: "spec",    state: "healthy",  rps: 12,   p99: "44ms", dot: "ok" },
  { id: "pgvector",     kind: "db",      state: "healthy",  rps: 530,  p99: "6ms",  dot: "ok" },
];

window.PORTAL_I18N = I18N;
window.tFmt = tFmt;
window.NAV_GROUPS = NAV_GROUPS;
window.RUNS = RUNS;
window.APPROVALS = APPROVALS;
window.ACTIVITY = ACTIVITY;
window.SERVICES = SERVICES;
